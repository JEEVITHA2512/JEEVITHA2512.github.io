import { useState } from "react";
import AdminLayout from "./DashboardLayout";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { AdminPageHeader } from "@/components/admin/AdminPageHeader";
import { DataTable, Column } from "@/components/admin/DataTable";
import { FormDialog } from "@/components/admin/FormDialog";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { Button } from "@/components/ui/button";

const publicationSchema = z.object({
  id: z.number().optional(),
  title: z.string().min(1, "Title is required"),
  description: z.string().min(1, "Description is required"),
  link: z.string().url("Must be a valid URL").or(z.string().length(0)),
  publisher: z.string().optional(),
  date: z.string().min(1, "Date is required"),
});

type PublicationFormValues = z.infer<typeof publicationSchema>;

type Publication = {
  id: number;
  title: string;
  description: string;
  link: string;
  publisher: string | null;
  date: string;
};

const inputClass = "w-full bg-black/5 border-transparent focus:bg-white focus:border-black/20 focus:ring-0 outline-none rounded-xl px-4 py-3.5 transition-colors text-[15px]";

export default function PublicationsManager() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);

  const form = useForm<PublicationFormValues>({
    resolver: zodResolver(publicationSchema),
    defaultValues: { title: "", description: "", link: "", publisher: "", date: "" },
  });

  const { data: publications, isLoading } = useQuery<Publication[]>({
    queryKey: ["publications"],
    queryFn: async () => {
      const res = await fetch("/api/publications");
      if (!res.ok) throw new Error("Network response was not ok");
      return res.json();
    },
  });

  const saveMutation = useMutation({
    mutationFn: async (data: PublicationFormValues) => {
      const url = editingId ? `/api/publications/${editingId}` : "/api/publications";
      const method = editingId ? "PUT" : "POST";

      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Failed to save");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["publications"] });
      toast({ title: editingId ? "Publication Updated" : "Publication Added" });
      handleCloseDialog();
    },
    onError: () => {
      toast({ title: "Failed to save", variant: "destructive" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await fetch(`/api/publications/${id}`, { method: "DELETE" });
      if (!res.ok) throw new Error("Failed to delete");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["publications"] });
      toast({ title: "Deleted Successfully" });
    },
    onError: () => {
      toast({ title: "Failed to delete", variant: "destructive" });
    },
  });

  const handleOpenAdd = () => {
    setEditingId(null);
    form.reset({ title: "", description: "", link: "", publisher: "", date: "" });
    setIsDialogOpen(true);
  };

  const handleOpenEdit = (item: Publication) => {
    setEditingId(item.id);
    form.reset({
      title: item.title,
      description: item.description,
      link: item.link,
      publisher: item.publisher || "",
      date: item.date,
    });
    setIsDialogOpen(true);
  };

  const handleCloseDialog = () => {
    setIsDialogOpen(false);
    setTimeout(() => {
      form.reset();
      setEditingId(null);
    }, 200);
  };

  const onSubmit = (data: PublicationFormValues) => {
    saveMutation.mutate(data);
  };

  const columns: Column<Publication>[] = [
    { 
      header: "Title", 
      accessorKey: "title",
      cell: (item) => (
        <div>
          <span className="font-semibold block text-black">{item.title}</span>
          <span className="text-xs text-black/40 line-clamp-1 max-w-[300px]">{item.description}</span>
        </div>
      )
    },
    { 
      header: "Publisher / Type", 
      accessorKey: "publisher",
      cell: (item) => (
        <span className="px-2.5 py-1 bg-black/5 rounded-lg text-[11px] font-bold text-black/70">{item.publisher || "Research Paper"}</span>
      )
    },
    { 
      header: "Date", 
      accessorKey: "date",
      cell: (item) => (
        <span className="text-black/70 font-medium">{item.date}</span>
      )
    },
  ];

  return (
    <AdminLayout>
      <div className="space-y-6">
        <AdminPageHeader 
          title="Publications" 
          description="Manage your research papers and publications."
          onAdd={handleOpenAdd}
          addButtonText="Add Publication"
        />

        <DataTable 
          data={publications}
          columns={columns}
          isLoading={isLoading}
          onEdit={handleOpenEdit}
          onDelete={(id) => deleteMutation.mutate(id)}
          emptyMessage="No publications added yet."
        />

        <FormDialog 
          isOpen={isDialogOpen} 
          onOpenChange={(open) => !open && handleCloseDialog()} 
          title={editingId ? "Edit Publication" : "Add Publication"}
        >
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
            <div className="space-y-2">
              <label className="text-sm font-medium text-black/70 ml-1">Title</label>
              <input 
                {...form.register("title")}
                className={inputClass}
                placeholder="e.g. Data-driven Machine Learning Models..."
              />
              {form.formState.errors.title && <p className="text-red-500 text-xs ml-1">{form.formState.errors.title.message}</p>}
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-black/70 ml-1">Abstract / Description</label>
              <textarea 
                {...form.register("description")}
                className={`${inputClass} min-h-[100px] resize-y`}
                placeholder="Brief abstract..."
              />
              {form.formState.errors.description && <p className="text-red-500 text-xs ml-1">{form.formState.errors.description.message}</p>}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              <div className="space-y-2">
                <label className="text-sm font-medium text-black/70 ml-1">Publisher / Type</label>
                <input 
                  {...form.register("publisher")}
                  className={inputClass}
                  placeholder="e.g. Research Paper"
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium text-black/70 ml-1">Date</label>
                <input 
                  {...form.register("date")}
                  className={inputClass}
                  placeholder="e.g. Oct 2023"
                />
                {form.formState.errors.date && <p className="text-red-500 text-xs ml-1">{form.formState.errors.date.message}</p>}
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-black/70 ml-1">URL Link (Optional)</label>
              <input 
                {...form.register("link")}
                className={inputClass}
                placeholder="https://..."
              />
              {form.formState.errors.link && <p className="text-red-500 text-xs ml-1">{form.formState.errors.link.message}</p>}
            </div>

            <div className="pt-5 flex justify-end gap-3 border-t border-black/5 mt-6">
              <Button type="button" variant="admin-ghost" onClick={handleCloseDialog}>Cancel</Button>
              <Button type="submit" variant="admin-pill" disabled={saveMutation.isPending}>
                {saveMutation.isPending ? "Saving..." : (editingId ? "Update" : "Add Publication")}
              </Button>
            </div>
          </form>
        </FormDialog>
      </div>
    </AdminLayout>
  );
}

