import { useState, useEffect } from "react";
import AdminLayout from "./DashboardLayout";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Rss, Article } from "@phosphor-icons/react";

export default function BlogsManager() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: profile, isLoading: isProfileLoading } = useQuery({
    queryKey: ["profile"],
    queryFn: async () => {
      const res = await fetch("/api/profile");
      if (!res.ok) throw new Error("Network error");
      return res.json();
    },
  });

  const { data: blogsPreview, isLoading: isBlogsLoading } = useQuery({
    queryKey: ["blogs"],
    queryFn: async () => {
      const res = await fetch("/api/blogs");
      if (!res.ok) throw new Error("Network error");
      return res.json();
    },
    enabled: !!profile?.blogRssUrl, // Only fetch if we have an RSS URL
  });

  const [blogRssUrl, setBlogRssUrl] = useState("");

  useEffect(() => {
    if (profile) {
      setBlogRssUrl(profile.blogRssUrl || "");
    }
  }, [profile]);

  const updateMutation = useMutation({
    mutationFn: async (rssUrl: string) => {
      const res = await fetch("/api/profile", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...profile, blogRssUrl: rssUrl }),
      });
      if (!res.ok) throw new Error("Failed to update");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["profile"] });
      queryClient.invalidateQueries({ queryKey: ["blogs"] });
      toast({ title: "RSS Link updated successfully!" });
    },
    onError: () => {
      toast({ title: "Failed to update RSS link", variant: "destructive" });
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateMutation.mutate(blogRssUrl);
  };

  return (
    <AdminLayout>
      <div className="max-w-6xl mx-auto space-y-8">
        <div>
          <h1 className="text-4xl font-heading font-medium text-black mb-1">Blog Integration</h1>
          <p className="text-black/60 text-[15px]">Automatically fetch and display your articles via RSS.</p>
        </div>

        {isProfileLoading ? (
          <div className="flex justify-center py-20">
            <div className="w-8 h-8 border-2 border-black border-t-transparent rounded-full animate-spin"></div>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
            
            {/* Left Column: RSS Settings Form */}
            <div className="lg:col-span-5 space-y-6">
              <form onSubmit={handleSubmit} className="bg-white border border-black/10 p-8 rounded-[2rem] shadow-sm space-y-6">
                <div className="flex items-center gap-3 mb-4 border-b border-black/5 pb-4">
                  <div className="w-10 h-10 rounded-xl bg-orange-500/10 flex items-center justify-center text-orange-500">
                    <Rss size={20} weight="bold" />
                  </div>
                  <h2 className="text-2xl font-heading font-medium text-black">RSS Feed</h2>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium text-black/70 ml-1">Medium or Custom RSS URL</label>
                  <input 
                    name="blogRssUrl" 
                    value={blogRssUrl} 
                    onChange={(e) => setBlogRssUrl(e.target.value)} 
                    className="w-full bg-black/5 border-transparent focus:bg-white focus:border-black/20 focus:ring-0 outline-none rounded-xl px-4 py-3.5 transition-colors text-[15px]" 
                    placeholder="e.g. https://medium.com/feed/@username" 
                  />
                  <p className="text-xs text-black/40 px-2 mt-2">
                    Enter the URL of your RSS feed. The portfolio will automatically fetch your latest articles from this link.
                  </p>
                </div>

                <div className="pt-4">
                  <Button type="submit" variant="admin-pill" disabled={updateMutation.isPending} className="w-full py-6 text-[15px]">
                    {updateMutation.isPending ? "Connecting..." : "Save Connection"}
                  </Button>
                </div>
              </form>
            </div>

            {/* Right Column: Live Preview */}
            <div className="lg:col-span-7 space-y-6">
              <div className="bg-black/[0.02] border border-black/5 p-8 rounded-[2rem] min-h-[400px]">
                <div className="flex items-center gap-3 mb-6">
                  <Article size={20} className="text-black/40" />
                  <h3 className="font-medium text-black/60">Live Preview</h3>
                </div>

                {!profile?.blogRssUrl ? (
                  <div className="flex flex-col items-center justify-center h-64 text-center">
                    <Rss size={48} className="text-black/10 mb-4" />
                    <p className="text-black/40">No RSS feed connected yet.</p>
                  </div>
                ) : isBlogsLoading ? (
                  <div className="flex justify-center py-20">
                    <div className="w-8 h-8 border-2 border-black/20 border-t-black rounded-full animate-spin"></div>
                  </div>
                ) : blogsPreview && blogsPreview.length > 0 ? (
                  <div className="space-y-4">
                    {blogsPreview.slice(0, 3).map((blog: any) => (
                      <a key={blog.id} href={blog.link} target="_blank" rel="noopener noreferrer" className="block p-5 bg-white border border-black/5 rounded-2xl hover:shadow-md transition-shadow">
                        <h4 className="font-heading font-medium text-black mb-1 line-clamp-1">{blog.title}</h4>
                        <p className="text-black/60 text-sm line-clamp-2">
                           {blog.description ? blog.description.replace(/<[^>]*>/g, "") : "No description available."}
                        </p>
                        <p className="text-black/40 text-xs mt-3">
                           {new Date(blog.date).toLocaleDateString()}
                        </p>
                      </a>
                    ))}
                    {blogsPreview.length > 3 && (
                      <p className="text-center text-sm text-black/40 pt-2">+ {blogsPreview.length - 3} more articles fetched</p>
                    )}
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center h-64 text-center">
                    <p className="text-orange-500">Could not fetch articles from this URL.</p>
                    <p className="text-black/40 text-sm mt-1">Make sure the RSS link is valid and publicly accessible.</p>
                  </div>
                )}
              </div>
            </div>

          </div>
        )}
      </div>
    </AdminLayout>
  );
}
