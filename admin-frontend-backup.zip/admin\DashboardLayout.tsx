import { Link, useLocation } from "wouter";
import { SignOut, Briefcase, Code, SquaresFour, User } from "@phosphor-icons/react";
import { useEffect, useState } from "react";
import { useToast } from "@/hooks/use-toast";

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null);

  useEffect(() => {
    fetch("/api/auth/me")
      .then((res) => {
        if (res.ok) setIsAuthenticated(true);
        else {
          setIsAuthenticated(false);
          setLocation("/admin/login");
        }
      })
      .catch(() => {
        setIsAuthenticated(false);
        setLocation("/admin/login");
      });
  }, [setLocation]);

  const handleLogout = async () => {
    await fetch("/api/auth/logout", { method: "POST" });
    toast({ title: "Logged out" });
    setLocation("/admin/login");
  };

  if (isAuthenticated === null) {
    return <div className="admin-theme min-h-screen flex items-center justify-center bg-white text-black">Loading...</div>;
  }

  if (isAuthenticated === false) return null;

  return (
    <div className="admin-theme flex h-screen bg-black/5 text-black p-6 gap-6 overflow-hidden">
      {/* Sidebar */}
      <aside className="w-[280px] bg-white rounded-[2rem] p-8 flex flex-col shadow-[0_8px_30px_rgb(0,0,0,0.04)] border border-black/5 shrink-0">
        <div className="flex items-center gap-2 mb-10">
          <span className="text-2xl text-black font-heading">
            Jeevitha Murugan
          </span>
          <span className="text-2xl select-none bg-gradient-to-tr from-[#73D3FB] via-[#86F9F9] to-[#DBFFC2] bg-clip-text text-transparent font-extrabold">✳︎</span>
        </div>
        
        <nav className="flex-1 space-y-1 overflow-y-auto pr-2 pb-4">
          <Link href="/admin" className="flex items-center gap-3 px-3 py-2 text-[15px] hover:opacity-60 transition-opacity text-black font-medium">
            <SquaresFour size={20} />
            Dashboard
          </Link>
          <Link href="/admin/profile" className="flex items-center gap-3 px-3 py-2 text-[15px] hover:opacity-60 transition-opacity text-black font-medium">
            <User size={20} />
            Profile Settings
          </Link>
          <div className="pt-6 pb-3">
            <p className="text-xs font-bold text-black/40 uppercase tracking-widest px-3">Content</p>
          </div>
          <Link href="/admin/experiences" className="flex items-center gap-3 px-3 py-2 text-[15px] hover:opacity-60 transition-opacity text-black font-medium">
            <Briefcase size={20} />
            Experiences
          </Link>
          <Link href="/admin/projects" className="flex items-center gap-3 px-3 py-2 text-[15px] hover:opacity-60 transition-opacity text-black font-medium">
            <Code size={20} />
            Projects
          </Link>
          <Link href="/admin/education" className="flex items-center gap-3 px-3 py-2 text-[15px] hover:opacity-60 transition-opacity text-black font-medium">
            <Briefcase size={20} />
            Education
          </Link>
          <Link href="/admin/certifications" className="flex items-center gap-3 px-3 py-2 text-[15px] hover:opacity-60 transition-opacity text-black font-medium">
            <Briefcase size={20} />
            Certifications
          </Link>
          <Link href="/admin/awards" className="flex items-center gap-3 px-3 py-2 text-[15px] hover:opacity-60 transition-opacity text-black font-medium">
            <Briefcase size={20} />
            Awards
          </Link>
          <Link href="/admin/blogs" className="flex items-center gap-3 px-3 py-2 text-[15px] hover:opacity-60 transition-opacity text-black font-medium">
            <Briefcase size={20} />
            Blogs
          </Link>
          <Link href="/admin/publications" className="flex items-center gap-3 px-3 py-2 text-[15px] hover:opacity-60 transition-opacity text-black font-medium">
            <Briefcase size={20} />
            Publications
          </Link>
          <Link href="/admin/patents" className="flex items-center gap-3 px-3 py-2 text-[15px] hover:opacity-60 transition-opacity text-black font-medium">
            <Briefcase size={20} />
            Patents
          </Link>
        </nav>
        <button
          onClick={handleLogout}
          className="flex items-center gap-3 px-3 py-2 text-[15px] text-red-500 hover:opacity-60 transition-opacity font-medium mt-auto"
        >
          <SignOut size={20} />
          Logout
        </button>
      </aside>

      {/* Main Content */}
      <main className="flex-1 bg-white rounded-[2rem] shadow-[0_8px_30px_rgb(0,0,0,0.04)] border border-black/5 overflow-hidden flex flex-col">
        <div className="flex-1 overflow-y-auto p-8 md:p-12">
          <div className="max-w-6xl mx-auto">
            {children}
          </div>
        </div>
      </main>
    </div>
  );
}
