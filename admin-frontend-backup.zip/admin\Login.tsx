import { useState } from "react";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { ShieldCheck } from "@phosphor-icons/react";

export default function AdminLogin() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password }),
      });

      if (res.ok) {
        toast({ title: "Login Successful", description: "Welcome to the Admin Dashboard." });
        setLocation("/admin");
      } else {
        const data = await res.json();
        toast({ title: "Login Failed", description: data.message, variant: "destructive" });
      }
    } catch (err) {
      toast({ title: "Error", description: "Could not connect to the server.", variant: "destructive" });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="admin-theme min-h-screen flex items-center justify-center bg-white text-black p-4">
      <div className="w-full max-w-[400px]">
        
        <div className="flex flex-col items-center mb-10 text-center">
          <div className="w-14 h-14 bg-black/5 rounded-2xl flex items-center justify-center mb-6">
            <ShieldCheck className="w-8 h-8 text-black" />
          </div>
          <h1 className="text-3xl font-heading font-medium mb-2">Admin Portal</h1>
          <p className="text-black/60 text-[15px]">Sign in to manage your portfolio.</p>
        </div>

        <form onSubmit={handleLogin} className="space-y-6">
          <div className="space-y-4">
            <div>
              <input
                type="text"
                placeholder="Username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full px-5 py-4 rounded-2xl bg-black/5 border-transparent focus:bg-white focus:border-black/20 focus:ring-0 outline-none transition-all placeholder:text-black/40 text-[15px]"
                required
              />
            </div>
            <div>
              <input
                type="password"
                placeholder="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-5 py-4 rounded-2xl bg-black/5 border-transparent focus:bg-white focus:border-black/20 focus:ring-0 outline-none transition-all placeholder:text-black/40 text-[15px]"
                required
              />
            </div>
          </div>
          
          <button
            type="submit"
            disabled={isLoading}
            className="w-full py-4 px-6 bg-black text-white rounded-full text-[15px] hover:bg-black/80 transition-colors disabled:opacity-50 flex justify-center items-center font-medium"
          >
            {isLoading ? "Authenticating..." : "Sign In"}
          </button>
        </form>

      </div>
    </div>
  );
}
