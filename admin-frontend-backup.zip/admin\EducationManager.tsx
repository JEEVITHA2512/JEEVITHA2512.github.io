import { useState } from "react";
import AdminLayout from "./DashboardLayout";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { AdminPageHeader } from "@/components/admin/AdminPageHeader";
import { DataTable, Column } from "@/components/admin/DataTable";
import { FormDialog } from "@/components/admin/FormDialog";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { Button } from "@/components/ui/button";

const educationSchema = z.object({
  id: z.number().optional(),
  degree: z.string().min(1, "Degree is required"),
  field: z.string().min(1, "Field is required"),
  institution: z.string().min(1, "Institution is required"),
  institutionType: z.string().optional(),
  date: z.string().min(1, "Date is required"),
  description: z.string().optional(),
});

type EducationFormValues = z.infer<typeof educationSchema>;

type Education = {
  id: number;
  degree: string;
  field: string;
  institution: string;
  institutionType: string | null;
  date: string;
  description: string | null;
};

const inputClass = "w-full bg-black/5 border-transparent focus:bg-white focus:border-black/20 focus:ring-0 outline-none rounded-xl px-4 py-3.5 transition-colors text-[15px]";

export default function EducationManager() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);

  const form = useForm<EducationFormValues>({
    resolver: zodResolver(educationSchema),
    defaultValues: {
      degree: "",
      field: "",
      institution: "",
      institutionType: "",
      date: "",
      description: "",
    },
  });

  const { data: education, isLoading } = useQuery<Education[]>({
    queryKey: ["education"],
    queryFn: async () => {
      const res = await fetch("/api/education");
      if (!res.ok) throw new Error("Network response was not ok");
      return res.json();
    },
  });

  const saveMutation = useMutation({
    mutationFn: async (data: EducationFormValues) => {
      const url = editingId ? `/api/education/${editingId}` : "/api/education";
      const method = editingId ? "PUT" : "POST";

      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Failed to save");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["education"] });
      toast({ title: editingId ? "Education Updated" : "Education Added" });
      handleCloseDialog();
    },
    onError: () => {
      toast({ title: "Failed to save", variant: "destructive" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await fetch(`/api/education/${id}`, { method: "DELETE" });
      if (!res.ok) throw new Error("Failed to delete");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["education"] });
      toast({ title: "Deleted Successfully" });
    },
    onError: () => {
      toast({ title: "Failed to delete", variant: "destructive" });
    },
  });

  const handleOpenAdd = () => {
    setEditingId(null);
    form.reset({
      degree: "",
      field: "",
      institution: "",
      institutionType: "",
      date: "",
      description: "",
    });
    setIsDialogOpen(true);
  };

  const handleOpenEdit = (item: Education) => {
    setEditingId(item.id);
    form.reset({
      degree: item.degree,
      field: item.field,
      institution: item.institution,
      institutionType: item.institutionType || "",
      date: item.date,
      description: item.description || "",
    });
    setIsDialogOpen(true);
  };

  const handleCloseDialog = () => {
    setIsDialogOpen(false);
    setTimeout(() => {
      form.reset();
      setEditingId(null);
    }, 200);
  };

  const onSubmit = (data: EducationFormValues) => {
    saveMutation.mutate(data);
  };

  const columns: Column<Education>[] = [
    {
      header: "Institution",
      cell: (item) => (
        <div>
          <span className="font-semibold text-black">{item.institution}</span>
          {item.institutionType && (
            <span className="block text-xs text-black/50 mt-0.5">{item.institutionType}</span>
          )}
        </div>
      ),
    },
    {
      header: "Degree & Field",
      cell: (item) => (
        <div>
          <span className="font-semibold text-black">{item.degree}</span>
          <span className="block text-xs text-black/50 mt-0.5">{item.field}</span>
        </div>
      ),
    },
    { header: "Date", accessorKey: "date" },
  ];

  return (
    <AdminLayout>
      <div className="space-y-6">
        <AdminPageHeader 
          title="Education" 
          description="Manage your academic background and degrees."
          onAdd={handleOpenAdd}
          addButtonText="Add Education"
        />

        <DataTable 
          data={education}
          columns={columns}
          isLoading={isLoading}
          onEdit={handleOpenEdit}
          onDelete={(id) => deleteMutation.mutate(id)}
          emptyMessage="No education records added yet."
        />

        <FormDialog 
          isOpen={isDialogOpen} 
          onOpenChange={(open) => !open && handleCloseDialog()} 
          title={editingId ? "Edit Education" : "Add Education"}
        >
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              <div className="space-y-2">
                <label className="text-sm font-medium text-black/70 ml-1">Institution</label>
                <input 
                  {...form.register("institution")}
                  className={inputClass}
                  placeholder="e.g. St. Joseph's College Of Engineering"
                />
                {form.formState.errors.institution && <p className="text-red-500 text-xs ml-1">{form.formState.errors.institution.message}</p>}
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium text-black/70 ml-1">Institution Type</label>
                <input 
                  {...form.register("institutionType")}
                  className={inputClass}
                  placeholder="e.g. Engineering College · Autonomous"
                />
                <p className="text-xs text-black/40 ml-1">Shown below the institution name on portfolio</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              <div className="space-y-2">
                <label className="text-sm font-medium text-black/70 ml-1">Degree</label>
                <input 
                  {...form.register("degree")}
                  className={inputClass}
                  placeholder="e.g. Bachelor of Technology - BTech"
                />
                {form.formState.errors.degree && <p className="text-red-500 text-xs ml-1">{form.formState.errors.degree.message}</p>}
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium text-black/70 ml-1">Field of Study</label>
                <input 
                  {...form.register("field")}
                  className={inputClass}
                  placeholder="e.g. Artificial Intelligence and Data Science"
                />
                {form.formState.errors.field && <p className="text-red-500 text-xs ml-1">{form.formState.errors.field.message}</p>}
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-black/70 ml-1">Date / Duration</label>
              <input 
                {...form.register("date")}
                className={inputClass}
                placeholder="e.g. Nov 2021 – May 2025"
              />
              {form.formState.errors.date && <p className="text-red-500 text-xs ml-1">{form.formState.errors.date.message}</p>}
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-black/70 ml-1">Description</label>
              <textarea 
                {...form.register("description")}
                rows={4}
                className={`${inputClass} resize-none`}
                placeholder="Describe your academic experience, key coursework, projects, achievements..."
              />
              <p className="text-xs text-black/40 ml-1">Shown as the description paragraph on the portfolio. Separate paragraphs with a blank line.</p>
            </div>

            <div className="pt-5 flex justify-end gap-3 border-t border-black/5 mt-6">
              <Button type="button" variant="admin-ghost" onClick={handleCloseDialog}>Cancel</Button>
              <Button type="submit" variant="admin-pill" disabled={saveMutation.isPending}>
                {saveMutation.isPending ? "Saving..." : (editingId ? "Update" : "Add Education")}
              </Button>
            </div>
          </form>
        </FormDialog>
      </div>
    </AdminLayout>
  );
}
