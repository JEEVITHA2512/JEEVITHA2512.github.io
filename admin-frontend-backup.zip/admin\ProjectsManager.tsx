import { useState } from "react";
import AdminLayout from "./DashboardLayout";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { AdminPageHeader } from "@/components/admin/AdminPageHeader";
import { DataTable, Column } from "@/components/admin/DataTable";
import { FormDialog } from "@/components/admin/FormDialog";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { Button } from "@/components/ui/button";
import { Image as ImageIcon, ArrowSquareOut } from "@phosphor-icons/react";
import { FaGithub } from "react-icons/fa6";
import { ImageUpload } from "@/components/ui/ImageUpload";

const projectSchema = z.object({
  id: z.number().optional(),
  title: z.string().min(1, "Title is required"),
  description: z.string().min(1, "Description is required"),
  github: z.string().optional(),
  link: z.string().optional(),
  coverImage: z.string().nullable(),
  tags: z.string().min(1, "Tags are required (comma separated)"),
});

type ProjectFormValues = z.infer<typeof projectSchema>;

type Project = {
  id: number;
  title: string;
  description: string;
  github: string | null;
  link: string | null;
  image: string | null;
  tags: string[];
};

const inputClass = "w-full bg-black/5 border-transparent focus:bg-white focus:border-black/20 focus:ring-0 outline-none rounded-xl px-4 py-3.5 transition-colors text-[15px]";

export default function ProjectsManager() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);

  const form = useForm<ProjectFormValues>({
    resolver: zodResolver(projectSchema),
    defaultValues: {
      title: "",
      description: "",
      github: "",
      link: "",
      coverImage: null,
      tags: "",
    },
  });

  const { data: projects, isLoading } = useQuery<Project[]>({
    queryKey: ["projects"],
    queryFn: async () => {
      const res = await fetch("/api/projects");
      if (!res.ok) throw new Error("Network response was not ok");
      return res.json();
    },
  });

  const saveMutation = useMutation({
    mutationFn: async (data: ProjectFormValues) => {
      const formattedData = {
        title: data.title,
        description: data.description,
        link: data.link || null,
        github: data.github || null,
        image: data.coverImage || null,
        tags: data.tags.split(",").map(s => s.trim()).filter(Boolean),
      };

      const url = editingId ? `/api/projects/${editingId}` : "/api/projects";
      const method = editingId ? "PUT" : "POST";

      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formattedData),
      });
      if (!res.ok) throw new Error("Failed to save");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["projects"] });
      toast({ title: editingId ? "Project Updated" : "Project Added" });
      handleCloseDialog();
    },
    onError: () => {
      toast({ title: "Failed to save", variant: "destructive" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await fetch(`/api/projects/${id}`, { method: "DELETE" });
      if (!res.ok) throw new Error("Failed to delete");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["projects"] });
      toast({ title: "Deleted Successfully" });
    },
    onError: () => {
      toast({ title: "Failed to delete", variant: "destructive" });
    },
  });

  const handleOpenAdd = () => {
    setEditingId(null);
    form.reset({
      title: "",
      description: "",
      github: "",
      link: "",
      coverImage: null,
      tags: "",
    });
    setIsDialogOpen(true);
  };

  const handleOpenEdit = (project: Project) => {
    setEditingId(project.id);
    form.reset({
      title: project.title,
      description: project.description,
      github: project.github || "",
      link: project.link || "",
      coverImage: project.image || null,
      tags: project.tags.join(", "),
    });
    setIsDialogOpen(true);
  };

  const handleCloseDialog = () => {
    setIsDialogOpen(false);
    setTimeout(() => {
      form.reset();
      setEditingId(null);
    }, 200);
  };

  const onSubmit = (data: ProjectFormValues) => {
    saveMutation.mutate(data);
  };

  const columns: Column<Project>[] = [
    {
      header: "Project",
      accessorKey: "title",
      cell: (item) => (
        <div className="flex items-center gap-3">
          {item.image ? (
            <img src={item.image} alt={item.title} className="w-10 h-10 rounded-md object-cover bg-muted border border-black/5" />
          ) : (
            <div className="w-10 h-10 rounded-md bg-primary/10 flex items-center justify-center border border-black/5">
              <ImageIcon className="text-primary w-5 h-5" />
            </div>
          )}
          <div>
            <span className="font-semibold block text-black">{item.title}</span>
            <span className="text-xs text-black/40 line-clamp-1 max-w-[250px]">{item.description}</span>
          </div>
        </div>
      ),
    },
    { 
      header: "Tags", 
      accessorKey: "tags",
      cell: (item) => (
        <div className="flex flex-wrap gap-1">
          {item.tags.slice(0, 3).map(tag => (
            <span key={tag} className="px-2.5 py-1 bg-black/5 rounded-lg text-[11px] font-bold text-black/70">{tag}</span>
          ))}
          {item.tags.length > 3 && (
            <span className="px-2 py-0.5 bg-black/5 rounded text-[11px] font-bold text-black/40">+{item.tags.length - 3}</span>
          )}
        </div>
      )
    },
    {
      header: "Links",
      accessorKey: "github",
      cell: (item) => (
        <div className="flex items-center gap-2">
          {item.github ? (
            <a
              href={item.github}
              target="_blank"
              rel="noopener noreferrer"
              className="text-black/50 hover:text-black transition-colors p-1.5 bg-black/5 hover:bg-black/10 rounded-lg border border-black/10 flex items-center justify-center"
              title="GitHub Link"
            >
              <FaGithub className="w-3.5 h-3.5" />
            </a>
          ) : (
            <span className="text-xs text-black/30 italic">No GitHub</span>
          )}
          {item.link ? (
            <a
              href={item.link}
              target="_blank"
              rel="noopener noreferrer"
              className="text-black/50 hover:text-black transition-colors p-1.5 bg-black/5 hover:bg-black/10 rounded-lg border border-black/10 flex items-center justify-center"
              title="Live Link"
            >
              <ArrowSquareOut className="w-3.5 h-3.5" />
            </a>
          ) : null}
        </div>
      ),
    },
  ];

  return (
    <AdminLayout>
      <div className="space-y-6">
        <AdminPageHeader 
          title="Projects" 
          description="Manage your portfolio projects and case studies."
          onAdd={handleOpenAdd}
          addButtonText="Add Project"
        />

        <DataTable 
          data={projects}
          columns={columns}
          isLoading={isLoading}
          onEdit={handleOpenEdit}
          onDelete={(id) => deleteMutation.mutate(id)}
          emptyMessage="No projects added yet."
        />

        <FormDialog 
          isOpen={isDialogOpen} 
          onOpenChange={(open) => !open && handleCloseDialog()} 
          title={editingId ? "Edit Project" : "Add New Project"}
        >
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
            <div className="space-y-2">
              <label className="text-sm font-medium text-black/70 ml-1">Title</label>
              <input 
                {...form.register("title")}
                className={inputClass}
                placeholder="e.g. E-Commerce Platform"
              />
              {form.formState.errors.title && <p className="text-red-500 text-xs ml-1">{form.formState.errors.title.message}</p>}
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-black/70 ml-1">Description</label>
              <textarea 
                {...form.register("description")}
                className={`${inputClass} min-h-[100px] resize-y`}
                placeholder="Brief summary of the project..."
              />
              {form.formState.errors.description && <p className="text-red-500 text-xs ml-1">{form.formState.errors.description.message}</p>}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              <div className="space-y-2">
                <label className="text-sm font-medium text-black/70 ml-1">GitHub URL</label>
                <input 
                  {...form.register("github")}
                  className={inputClass}
                  placeholder="https://github.com/..."
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium text-black/70 ml-1">Live Link URL</label>
                <input 
                  {...form.register("link")}
                  className={inputClass}
                  placeholder="https://..."
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-black/70 ml-1">Cover Image</label>
              <ImageUpload
                value={form.watch("coverImage") || ""}
                onChange={(url) => form.setValue("coverImage", url)}
                onRemove={() => form.setValue("coverImage", null)}
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-black/70 ml-1">Tags (comma separated)</label>
              <input 
                {...form.register("tags")}
                className={inputClass}
                placeholder="e.g. React, Node.js, TypeScript"
              />
              {form.formState.errors.tags && <p className="text-red-500 text-xs ml-1">{form.formState.errors.tags.message}</p>}
            </div>

            <div className="pt-5 flex justify-end gap-3 border-t border-black/5 mt-6">
              <Button type="button" variant="admin-ghost" onClick={handleCloseDialog}>Cancel</Button>
              <Button type="submit" variant="admin-pill" disabled={saveMutation.isPending}>
                {saveMutation.isPending ? "Saving..." : (editingId ? "Update Project" : "Add Project")}
              </Button>
            </div>
          </form>
        </FormDialog>
      </div>
    </AdminLayout>
  );
}

