import { useState, useEffect } from "react";
import AdminLayout from "./DashboardLayout";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { User, Briefcase, Link as LinkIcon, Camera, X, MapPin, RssSimple } from "@phosphor-icons/react";

export default function ProfileManager() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: profile, isLoading } = useQuery({
    queryKey: ["profile"],
    queryFn: async () => {
      const res = await fetch("/api/profile");
      if (!res.ok) throw new Error("Network error");
      return res.json();
    },
  });

  const [formData, setFormData] = useState({
    name: "",
    title: "",
    tagline: "",
    about: "",
    avatarUrl: "",
    yearsExperience: "",
    studentsMentored: "",
    github: "",
    linkedin: "",
    email: "",
    techSkills: "",
    location: "",
    role: "",
    community: "",
    blogRssUrl: "",
    googleScholarUrl: "",
    experienceTitle: "",
    experienceSub: "",
    mentorshipTitle: "",
    mentorshipSub: "",
  });

  const [isUploadingAvatar, setIsUploadingAvatar] = useState(false);

  const handleAvatarUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || e.target.files.length === 0) return;
    
    const file = e.target.files[0];
    setIsUploadingAvatar(true);

    try {
      const res = await fetch("/api/storage/presigned-url", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ filename: file.name, contentType: file.type }),
      });

      if (!res.ok) throw new Error("Failed to get upload URL");
      const { uploadUrl, publicUrl } = await res.json();

      const uploadRes = await fetch(uploadUrl, {
        method: "PUT",
        headers: { "Content-Type": file.type },
        body: file,
      });

      if (!uploadRes.ok) throw new Error("Failed to upload image");

      setFormData(prev => ({ ...prev, avatarUrl: publicUrl }));
      toast({ title: "Avatar Uploaded Successfully" });

    } catch (err) {
      toast({ title: "Upload Failed", variant: "destructive" });
      console.error(err);
    } finally {
      setIsUploadingAvatar(false);
    }
  };

  useEffect(() => {
    if (profile) {
      setFormData({
        name: profile.name || "",
        title: profile.title || "",
        tagline: profile.tagline || "",
        about: profile.about || "",
        avatarUrl: profile.avatarUrl || "",
        yearsExperience: profile.yearsExperience || "",
        studentsMentored: profile.studentsMentored || "",
        github: profile.github || "",
        linkedin: profile.linkedin || "",
        email: profile.email || "",
        techSkills: Array.isArray(profile.techSkills) ? profile.techSkills.join(", ") : "",
        location: profile.location || "",
        role: profile.role || "",
        community: profile.community || "",
        blogRssUrl: profile.blogRssUrl || "",
        googleScholarUrl: profile.googleScholarUrl || "",
        experienceTitle: profile.experienceTitle || "",
        experienceSub: profile.experienceSub || "",
        mentorshipTitle: profile.mentorshipTitle || "",
        mentorshipSub: profile.mentorshipSub || "",
      });
    }
  }, [profile]);

  const updateMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await fetch("/api/profile", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...data,
          techSkills: data.techSkills.split(",").map((s: string) => s.trim()).filter(Boolean)
        }),
      });
      if (!res.ok) throw new Error("Failed to update");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["profile"] });
      toast({ title: "Profile updated successfully" });
    },
    onError: () => {
      toast({ title: "Failed to update profile", variant: "destructive" });
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateMutation.mutate(formData);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const inputClass = "w-full bg-black/5 border-transparent focus:bg-white focus:border-black/20 focus:ring-0 outline-none rounded-xl px-4 py-3.5 transition-colors text-[15px]";

  return (
    <AdminLayout>
      <div className="max-w-6xl mx-auto space-y-8">
        <div>
          <h1 className="text-4xl font-heading font-medium text-black mb-1">Profile Settings</h1>
          <p className="text-black/60 text-[15px]">Manage your personal brand, public contact information, and portfolio sidebar.</p>
        </div>

        {isLoading ? (
          <div className="flex justify-center py-20">
            <div className="w-8 h-8 border-2 border-black border-t-transparent rounded-full animate-spin"></div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="grid grid-cols-1 lg:grid-cols-12 gap-10">
            
            {/* Left Column: Avatar & Live Preview */}
            <div className="lg:col-span-4 space-y-6">
              <div className="bg-black/[0.02] border border-black/5 p-8 rounded-[2rem] flex flex-col items-center text-center">
                <div className="relative mb-6">
                  <div className="w-40 h-40 rounded-full p-1 bg-gradient-to-tr from-[#73D3FB] via-[#86F9F9] to-[#DBFFC2] shadow-xl relative">
                    <div className="w-full h-full rounded-full overflow-hidden bg-white border-2 border-white flex items-center justify-center relative">
                      {isUploadingAvatar && (
                        <div className="absolute inset-0 bg-white/80 flex items-center justify-center z-10">
                          <div className="w-8 h-8 border-2 border-black border-t-transparent rounded-full animate-spin"></div>
                        </div>
                      )}
                      {formData.avatarUrl ? (
                        <img src={formData.avatarUrl} alt="Avatar" className="w-full h-full object-cover" />
                      ) : (
                        <User size={64} weight="duotone" className="text-black/20" />
                      )}
                    </div>
                  </div>
                  
                  {/* Camera Upload Button */}
                  <label className="absolute bottom-0 right-0 w-10 h-10 bg-white border border-black/10 rounded-full shadow-lg flex items-center justify-center cursor-pointer hover:bg-black hover:text-white transition-all text-black">
                    <Camera size={20} weight="bold" />
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleAvatarUpload}
                      disabled={isUploadingAvatar}
                      className="hidden"
                    />
                  </label>

                  {/* Remove Button */}
                  {formData.avatarUrl && (
                    <button
                      type="button"
                      onClick={() => setFormData(prev => ({ ...prev, avatarUrl: "" }))}
                      className="absolute top-0 right-0 w-8 h-8 bg-white border border-black/10 rounded-full shadow-md flex items-center justify-center hover:bg-red-500 hover:text-white text-black transition-colors"
                      title="Remove Avatar"
                    >
                      <X size={16} weight="bold" />
                    </button>
                  )}
                </div>
                <h3 className="text-xl font-heading font-medium text-black mb-1">{formData.name || "Your Name"}</h3>
                <p className="text-black/50 text-[15px] font-medium">{formData.title || "Job Title"}</p>
              </div>

              {/* Live Preview Card — mirrors the public portfolio sidebar */}
              <div className="bg-black text-white p-8 rounded-[2rem] shadow-xl">
                <h4 className="font-heading text-xl mb-5 text-white/90">Sidebar Preview</h4>
                <div className="space-y-3 text-[14px]">
                  <div className="flex justify-between border-b border-white/10 pb-2.5">
                    <span className="text-white/50">Location</span>
                    <span className="font-medium">{formData.location || "—"}</span>
                  </div>
                  <div className="flex justify-between border-b border-white/10 pb-2.5">
                    <span className="text-white/50">Email</span>
                    <span className="font-medium truncate max-w-[140px]">{formData.email || "—"}</span>
                  </div>
                  <div className="flex justify-between border-b border-white/10 pb-2.5">
                    <span className="text-white/50">Role</span>
                    <span className="font-medium">{formData.role || "—"}</span>
                  </div>
                  <div className="flex justify-between border-b border-white/10 pb-2.5">
                    <span className="text-white/50">Community</span>
                    <span className="font-medium">{formData.community || "—"}</span>
                  </div>
                  <div className="flex justify-between border-b border-white/10 pb-2.5">
                    <span className="text-white/50">{formData.experienceTitle || "Experience"}</span>
                    <span className="font-medium">{formData.yearsExperience || "0"}</span>
                  </div>
                  <div className="flex justify-between pb-1">
                    <span className="text-white/50">{formData.mentorshipTitle || "Mentorship"}</span>
                    <span className="font-medium">{formData.studentsMentored || "0"}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Right Column: Settings Form */}
            <div className="lg:col-span-8 space-y-8">
              
              {/* Basic Info Section */}
              <div className="bg-white border border-black/10 p-8 md:p-10 rounded-[2rem] shadow-sm space-y-6">
                <div className="flex items-center gap-3 mb-8 border-b border-black/5 pb-6">
                  <div className="w-10 h-10 rounded-xl bg-black/5 flex items-center justify-center text-black">
                    <User size={20} weight="bold" />
                  </div>
                  <h2 className="text-2xl font-heading font-medium text-black">Basic Information</h2>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-black/70 ml-1">Full Name</label>
                    <input name="name" value={formData.name} onChange={handleChange} className={inputClass} required />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-black/70 ml-1">Job Title</label>
                    <input name="title" value={formData.title} onChange={handleChange} className={inputClass} required />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium text-black/70 ml-1">Tagline</label>
                  <input name="tagline" value={formData.tagline} onChange={handleChange} className={inputClass} placeholder="e.g. Building scalable AI solutions" />
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium text-black/70 ml-1">About Me</label>
                  <textarea name="about" value={formData.about} onChange={handleChange} rows={6} className={`${inputClass} resize-none`} required />
                </div>
              </div>

              {/* Profile Details Section — NEW */}
              <div className="bg-white border border-black/10 p-8 md:p-10 rounded-[2rem] shadow-sm space-y-6">
                <div className="flex items-center gap-3 mb-8 border-b border-black/5 pb-6">
                  <div className="w-10 h-10 rounded-xl bg-black/5 flex items-center justify-center text-black">
                    <MapPin size={20} weight="bold" />
                  </div>
                  <div>
                    <h2 className="text-2xl font-heading font-medium text-black">Profile Details</h2>
                    <p className="text-black/40 text-xs mt-0.5">These appear in the sidebar of your portfolio</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-black/70 ml-1">Location</label>
                    <input name="location" value={formData.location} onChange={handleChange} className={inputClass} placeholder="e.g. Chennai, India" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-black/70 ml-1">Current Role</label>
                    <input name="role" value={formData.role} onChange={handleChange} className={inputClass} placeholder="e.g. GenAI Engineer @ BigTapp" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-black/70 ml-1">Community</label>
                    <input name="community" value={formData.community} onChange={handleChange} className={inputClass} placeholder="e.g. AWS Community Builder" />
                  </div>
                </div>
              </div>

              {/* Technical Profile Section */}
              <div className="bg-white border border-black/10 p-8 md:p-10 rounded-[2rem] shadow-sm space-y-6">
                <div className="flex items-center gap-3 mb-8 border-b border-black/5 pb-6">
                  <div className="w-10 h-10 rounded-xl bg-black/5 flex items-center justify-center text-black">
                    <Briefcase size={20} weight="bold" />
                  </div>
                  <h2 className="text-2xl font-heading font-medium text-black">Technical Profile</h2>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium text-black/70 ml-1">Tech Skills (Comma separated)</label>
                  <input name="techSkills" value={formData.techSkills} onChange={handleChange} className={inputClass} required placeholder="React, Node.js, TypeScript..." />
                </div>
              </div>

              {/* About Me Metrics Section */}
              <div className="bg-white border border-black/10 p-8 md:p-10 rounded-[2rem] shadow-sm space-y-6">
                <div className="flex items-center gap-3 mb-8 border-b border-black/5 pb-6">
                  <div className="w-10 h-10 rounded-xl bg-black/5 flex items-center justify-center text-black">
                    <Briefcase size={20} weight="bold" />
                  </div>
                  <div>
                    <h2 className="text-2xl font-heading font-medium text-black">About Me Stat Metrics</h2>
                    <p className="text-black/40 text-xs mt-0.5">Customize the two statistics cards displayed in the About Me section</p>
                  </div>
                </div>

                <div className="space-y-6">
                  {/* Card 1 (Experience) */}
                  <div className="space-y-4 p-5 rounded-2xl bg-black/[0.02] border border-black/5">
                    <h3 className="text-base font-semibold text-black/85">Stat Card 1</h3>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="space-y-2">
                        <label className="text-xs font-semibold text-black/60 ml-1">Title / Label</label>
                        <input name="experienceTitle" value={formData.experienceTitle} onChange={handleChange} className={inputClass} placeholder="e.g. Experience" />
                      </div>
                      <div className="space-y-2">
                        <label className="text-xs font-semibold text-black/60 ml-1">Value</label>
                        <input name="yearsExperience" value={formData.yearsExperience} onChange={handleChange} className={inputClass} placeholder="e.g. 2+" />
                      </div>
                      <div className="space-y-2">
                        <label className="text-xs font-semibold text-black/60 ml-1">Description / Subtext</label>
                        <input name="experienceSub" value={formData.experienceSub} onChange={handleChange} className={inputClass} placeholder="e.g. Full-time & Internship work" />
                      </div>
                    </div>
                  </div>

                  {/* Card 2 (Mentorship) */}
                  <div className="space-y-4 p-5 rounded-2xl bg-black/[0.02] border border-black/5">
                    <h3 className="text-base font-semibold text-black/85">Stat Card 2</h3>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="space-y-2">
                        <label className="text-xs font-semibold text-black/60 ml-1">Title / Label</label>
                        <input name="mentorshipTitle" value={formData.mentorshipTitle} onChange={handleChange} className={inputClass} placeholder="e.g. Mentorship" />
                      </div>
                      <div className="space-y-2">
                        <label className="text-xs font-semibold text-black/60 ml-1">Value</label>
                        <input name="studentsMentored" value={formData.studentsMentored} onChange={handleChange} className={inputClass} placeholder="e.g. 450+" />
                      </div>
                      <div className="space-y-2">
                        <label className="text-xs font-semibold text-black/60 ml-1">Description / Subtext</label>
                        <input name="mentorshipSub" value={formData.mentorshipSub} onChange={handleChange} className={inputClass} placeholder="e.g. AWS Clubs & User Groups guided" />
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Contact & Social Links Section */}
              <div className="bg-white border border-black/10 p-8 md:p-10 rounded-[2rem] shadow-sm space-y-6">
                <div className="flex items-center gap-3 mb-8 border-b border-black/5 pb-6">
                  <div className="w-10 h-10 rounded-xl bg-black/5 flex items-center justify-center text-black">
                    <LinkIcon size={20} weight="bold" />
                  </div>
                  <h2 className="text-2xl font-heading font-medium text-black">Social & Contact</h2>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-black/70 ml-1">Email</label>
                    <input name="email" value={formData.email} onChange={handleChange} className={inputClass} placeholder="hello@example.com" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-black/70 ml-1">GitHub URL</label>
                    <input name="github" value={formData.github} onChange={handleChange} className={inputClass} placeholder="https://github.com/..." />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-black/70 ml-1">LinkedIn URL</label>
                    <input name="linkedin" value={formData.linkedin} onChange={handleChange} className={inputClass} placeholder="https://linkedin.com/in/..." />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium text-black/70 ml-1 flex items-center gap-2">
                    <RssSimple size={16} weight="bold" className="text-black/40" />
                    Blog RSS Feed URL
                  </label>
                  <input name="blogRssUrl" value={formData.blogRssUrl} onChange={handleChange} className={inputClass} placeholder="https://medium.com/feed/@username" />
                  <p className="text-xs text-black/40 ml-1">Used to auto-fetch your latest blog posts on the portfolio</p>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium text-black/70 ml-1">Google Scholar Profile URL</label>
                  <input name="googleScholarUrl" value={formData.googleScholarUrl} onChange={handleChange} className={inputClass} placeholder="https://scholar.google.com/citations?user=..." />
                  <p className="text-xs text-black/40 ml-1">Links the "Read More" button in your Publications section to your Google Scholar page</p>
                </div>
              </div>

              <div className="pt-4 sticky bottom-8">
                <div className="bg-white/80 backdrop-blur-md p-4 rounded-full border border-black/10 shadow-2xl flex justify-between items-center">
                  <Button type="submit" variant="admin-pill" disabled={updateMutation.isPending} className="w-full sm:w-auto px-10 py-6 text-[15px] shadow-xl shadow-black/20">
                    {updateMutation.isPending ? "Saving changes..." : "Save Profile"}
                  </Button>
                  <p className="text-black/50 text-sm mr-4 hidden sm:block">Remember to save your changes before leaving.</p>
                </div>
              </div>

            </div>
          </form>
        )}
      </div>
    </AdminLayout>
  );
}
