import AdminLayout from "./DashboardLayout";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { 
  Briefcase, Code, GraduationCap, Certificate, 
  Trophy, Article, BookOpen, Lightbulb, ArrowRight 
} from "@phosphor-icons/react";

const useCount = (key: string, endpoint: string) => {
  return useQuery({
    queryKey: [key],
    queryFn: async () => {
      const res = await fetch(endpoint);
      if (!res.ok) return 0;
      const data = await res.json();
      return Array.isArray(data) ? data.length : 0;
    },
  });
};

export default function AdminDashboard() {
  const { data: expCount, isLoading: expLoading } = useCount("experiences", "/api/experiences");
  const { data: projCount, isLoading: projLoading } = useCount("projects", "/api/projects");
  const { data: eduCount, isLoading: eduLoading } = useCount("education", "/api/education");
  const { data: certCount, isLoading: certLoading } = useCount("certifications", "/api/certifications");
  const { data: awardCount, isLoading: awardLoading } = useCount("awards", "/api/awards");
  const { data: blogCount, isLoading: blogLoading } = useCount("blogs", "/api/blogs");
  const { data: pubCount, isLoading: pubLoading } = useCount("publications", "/api/publications");
  const { data: patCount, isLoading: patLoading } = useCount("patents", "/api/patents");

  const metrics = [
    { label: "Experiences", count: expCount, loading: expLoading, icon: Briefcase, color: "bg-blue-500", link: "/admin/experiences" },
    { label: "Projects", count: projCount, loading: projLoading, icon: Code, color: "bg-teal-500", link: "/admin/projects" },
    { label: "Education", count: eduCount, loading: eduLoading, icon: GraduationCap, color: "bg-green-500", link: "/admin/education" },
    { label: "Certifications", count: certCount, loading: certLoading, icon: Certificate, color: "bg-yellow-500", link: "/admin/certifications" },
    { label: "Awards", count: awardCount, loading: awardLoading, icon: Trophy, color: "bg-orange-500", link: "/admin/awards" },
    { label: "Blogs", count: blogCount, loading: blogLoading, icon: Article, color: "bg-pink-500", link: "/admin/blogs" },
    { label: "Publications", count: pubCount, loading: pubLoading, icon: BookOpen, color: "bg-cyan-500", link: "/admin/publications" },
    { label: "Patents", count: patCount, loading: patLoading, icon: Lightbulb, color: "bg-red-500", link: "/admin/patents" },
  ];

  return (
    <AdminLayout>
      <div className="space-y-10">
        <div>
          <h1 className="text-4xl font-heading font-medium text-black mb-1">Dashboard</h1>
          <p className="text-black/60 text-[15px]">
            Welcome to your Portfolio Admin Dashboard. Here's a quick overview of your content.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {metrics.map((metric) => (
            <Link key={metric.label} href={metric.link}>
              <div className="group relative p-6 border border-black/5 rounded-[2rem] bg-black/[0.02] hover:bg-white hover:border-black/10 hover:shadow-lg transition-all duration-300 cursor-pointer overflow-hidden flex flex-col h-full">
                <div className="flex justify-between items-start mb-6">
                  <div className={`w-12 h-12 rounded-2xl ${metric.color}/10 flex items-center justify-center text-${metric.color.replace('bg-', '')}`}>
                    <metric.icon size={24} weight="duotone" />
                  </div>
                  <div className="w-8 h-8 rounded-full bg-black/5 flex items-center justify-center group-hover:bg-black group-hover:text-white transition-colors duration-300">
                    <ArrowRight size={14} weight="bold" />
                  </div>
                </div>
                
                <div className="mt-auto">
                  <p className="text-black/50 text-sm font-medium tracking-wide uppercase mb-1">{metric.label}</p>
                  <h3 className="text-4xl font-heading font-medium text-black">
                    {metric.loading ? (
                      <span className="inline-block w-8 h-8 border-2 border-black/20 border-t-black rounded-full animate-spin"></span>
                    ) : (
                      metric.count
                    )}
                  </h3>
                </div>
              </div>
            </Link>
          ))}
        </div>

        <div className="bg-black text-white rounded-[2rem] p-8 md:p-12 relative overflow-hidden flex flex-col md:flex-row items-center justify-between gap-8 shadow-xl">
          <div className="relative z-10 max-w-xl">
            <h2 className="text-3xl font-heading font-medium mb-2">Need to update your profile?</h2>
            <p className="text-white/70 text-[15px] mb-6">Keep your contact information, tagline, and technical skills up to date so visitors always see your latest self.</p>
            <Link href="/admin/profile">
              <button className="px-6 py-3 bg-white text-black rounded-full font-medium hover:bg-white/90 transition-colors text-[15px]">
                Go to Profile Settings
              </button>
            </Link>
          </div>
          <div className="relative z-10 bg-white/10 p-6 rounded-3xl backdrop-blur-sm border border-white/10 hidden md:block">
             <UserCircle size={80} weight="duotone" className="text-white opacity-80" />
          </div>
          
          <div className="absolute top-[-50%] right-[-10%] w-[500px] h-[500px] bg-gradient-to-br from-[#73D3FB]/30 via-[#86F9F9]/20 to-[#DBFFC2]/10 rounded-full blur-3xl mix-blend-screen opacity-70"></div>
        </div>
      </div>
    </AdminLayout>
  );
}

function UserCircle({ size, weight, className }: any) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width={size} height={size} fill="currentColor" viewBox="0 0 256 256" className={className}>
      <rect width="256" height="256" fill="none"></rect>
      <circle cx="128" cy="128" r="96" opacity="0.2"></circle>
      <circle cx="128" cy="120" r="40" fill="none" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="16"></circle>
      <path d="M63.8,199.37a72,72,0,0,1,128.4,0" fill="none" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="16"></path>
      <circle cx="128" cy="128" r="96" fill="none" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="16"></circle>
    </svg>
  );
}
