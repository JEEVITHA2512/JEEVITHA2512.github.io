import { useState } from "react";
import AdminLayout from "./DashboardLayout";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { AdminPageHeader } from "@/components/admin/AdminPageHeader";
import { DataTable, Column } from "@/components/admin/DataTable";
import { FormDialog } from "@/components/admin/FormDialog";
import { useForm, useFieldArray } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { Button } from "@/components/ui/button";
import { Plus, Trash } from "@phosphor-icons/react";

const experienceSchema = z.object({
  id: z.number().optional(),
  role: z.string().min(1, "Role is required"),
  company: z.string().min(1, "Company is required"),
  companyDescription: z.string().optional(),
  date: z.string().min(1, "Date is required"),
  duration: z.string().min(1, "Duration is required"),
  location: z.string().min(1, "Location is required"),
  highlights: z.array(z.object({ value: z.string() })).min(1, "At least one highlight is required"),
  skills: z.string().min(1, "Skills are required (comma separated)"),
});

type ExperienceFormValues = z.infer<typeof experienceSchema>;

type Experience = {
  id: number;
  role: string;
  company: string;
  companyDescription: string | null;
  date: string;
  duration: string;
  location: string;
  highlights: string[];
  skills: string[];
};

const inputClass = "w-full bg-black/5 border-transparent focus:bg-white focus:border-black/20 focus:ring-0 outline-none rounded-xl px-4 py-3.5 transition-colors text-[15px]";

export default function ExperiencesManager() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);

  const form = useForm<ExperienceFormValues>({
    resolver: zodResolver(experienceSchema),
    defaultValues: {
      role: "",
      company: "",
      companyDescription: "",
      date: "",
      duration: "",
      location: "",
      highlights: [{ value: "" }],
      skills: "",
    },
  });

  const { fields: highlightFields, append: appendHighlight, remove: removeHighlight } = useFieldArray({
    control: form.control,
    name: "highlights",
  });

  const { data: experiences, isLoading } = useQuery<Experience[]>({
    queryKey: ["experiences"],
    queryFn: async () => {
      const res = await fetch("/api/experiences");
      if (!res.ok) throw new Error("Network response was not ok");
      return res.json();
    },
  });

  const saveMutation = useMutation({
    mutationFn: async (data: ExperienceFormValues) => {
      const formattedData = {
        ...data,
        highlights: data.highlights.map(h => h.value).filter(Boolean),
        skills: data.skills.split(",").map(s => s.trim()).filter(Boolean),
      };

      const url = editingId ? `/api/experiences/${editingId}` : "/api/experiences";
      const method = editingId ? "PUT" : "POST";

      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formattedData),
      });
      if (!res.ok) throw new Error("Failed to save");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["experiences"] });
      toast({ title: editingId ? "Experience Updated" : "Experience Added" });
      handleCloseDialog();
    },
    onError: () => {
      toast({ title: "Failed to save", variant: "destructive" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await fetch(`/api/experiences/${id}`, { method: "DELETE" });
      if (!res.ok) throw new Error("Failed to delete");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["experiences"] });
      toast({ title: "Deleted Successfully" });
    },
    onError: () => {
      toast({ title: "Failed to delete", variant: "destructive" });
    },
  });

  const handleOpenAdd = () => {
    setEditingId(null);
    form.reset({
      role: "",
      company: "",
      companyDescription: "",
      date: "",
      duration: "",
      location: "",
      highlights: [{ value: "" }],
      skills: "",
    });
    setIsDialogOpen(true);
  };

  const handleOpenEdit = (exp: Experience) => {
    setEditingId(exp.id);
    form.reset({
      role: exp.role,
      company: exp.company,
      companyDescription: exp.companyDescription || "",
      date: exp.date,
      duration: exp.duration,
      location: exp.location,
      highlights: exp.highlights.length > 0 ? exp.highlights.map(h => ({ value: h })) : [{ value: "" }],
      skills: exp.skills.join(", "),
    });
    setIsDialogOpen(true);
  };

  const handleCloseDialog = () => {
    setIsDialogOpen(false);
    setTimeout(() => {
      form.reset();
      setEditingId(null);
    }, 200);
  };

  const onSubmit = (data: ExperienceFormValues) => {
    saveMutation.mutate(data);
  };

  const columns: Column<Experience>[] = [
    {
      header: "Company",
      accessorKey: "company",
      cell: (item) => (
        <div>
          <span className="font-semibold text-black">{item.company}</span>
          {item.companyDescription && (
            <span className="block text-xs text-black/50 mt-0.5">{item.companyDescription}</span>
          )}
        </div>
      ),
    },
    { header: "Role", accessorKey: "role" },
    { header: "Date", accessorKey: "date" },
    { header: "Location", accessorKey: "location" },
  ];

  return (
    <AdminLayout>
      <div className="space-y-6">
        <AdminPageHeader 
          title="Experiences" 
          description="Manage your work history and internships."
          onAdd={handleOpenAdd}
          addButtonText="Add Experience"
        />

        <DataTable 
          data={experiences}
          columns={columns}
          isLoading={isLoading}
          onEdit={handleOpenEdit}
          onDelete={(id) => deleteMutation.mutate(id)}
          emptyMessage="No experiences added yet."
        />

        <FormDialog 
          isOpen={isDialogOpen} 
          onOpenChange={(open) => !open && handleCloseDialog()} 
          title={editingId ? "Edit Experience" : "Add New Experience"}
        >
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              <div className="space-y-2">
                <label className="text-sm font-medium text-black/70 ml-1">Company Name</label>
                <input 
                  {...form.register("company")}
                  className={inputClass}
                  placeholder="e.g. BigTapp Analytics"
                />
                {form.formState.errors.company && <p className="text-red-500 text-xs ml-1">{form.formState.errors.company.message}</p>}
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium text-black/70 ml-1">Company Subtitle</label>
                <input 
                  {...form.register("companyDescription")}
                  className={inputClass}
                  placeholder="e.g. Cognitive Data & AI Services"
                />
                <p className="text-xs text-black/40 ml-1">Shown below the company name on portfolio</p>
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-black/70 ml-1">Role / Position</label>
              <input 
                {...form.register("role")}
                className={inputClass}
                placeholder="e.g. Data Scientist"
              />
              {form.formState.errors.role && <p className="text-red-500 text-xs ml-1">{form.formState.errors.role.message}</p>}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
              <div className="space-y-2">
                <label className="text-sm font-medium text-black/70 ml-1">Date Range</label>
                <input 
                  {...form.register("date")}
                  className={inputClass}
                  placeholder="e.g. Jan 2023 - Present"
                />
                {form.formState.errors.date && <p className="text-red-500 text-xs ml-1">{form.formState.errors.date.message}</p>}
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium text-black/70 ml-1">Duration</label>
                <input 
                  {...form.register("duration")}
                  className={inputClass}
                  placeholder="e.g. 1 yr 5 mos"
                />
                {form.formState.errors.duration && <p className="text-red-500 text-xs ml-1">{form.formState.errors.duration.message}</p>}
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium text-black/70 ml-1">Location</label>
                <input 
                  {...form.register("location")}
                  className={inputClass}
                  placeholder="e.g. Chennai, India · On-site"
                />
                {form.formState.errors.location && <p className="text-red-500 text-xs ml-1">{form.formState.errors.location.message}</p>}
              </div>
            </div>

            <div className="space-y-3">
              <label className="text-sm font-medium text-black/70 ml-1">Highlights / Responsibilities</label>
              {highlightFields.map((field, index) => (
                <div key={field.id} className="flex gap-2">
                  <input
                    {...form.register(`highlights.${index}.value` as const)}
                    className={`flex-1 ${inputClass}`}
                    placeholder="e.g. Developed key features using React"
                  />
                  <button
                    type="button"
                    onClick={() => removeHighlight(index)}
                    className="px-3 py-2 text-red-500 bg-red-500/10 hover:bg-red-500/20 rounded-xl transition-colors shrink-0"
                  >
                    <Trash size={18} />
                  </button>
                </div>
              ))}
              <Button type="button" variant="outline" onClick={() => appendHighlight({ value: "" })} className="w-full mt-1 rounded-xl border-dashed">
                <Plus className="mr-2" size={16} /> Add Highlight
              </Button>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-black/70 ml-1">Skills (comma separated)</label>
              <input 
                {...form.register("skills")}
                className={inputClass}
                placeholder="e.g. React, Node.js, TypeScript"
              />
              {form.formState.errors.skills && <p className="text-red-500 text-xs ml-1">{form.formState.errors.skills.message}</p>}
            </div>

            <div className="pt-5 flex justify-end gap-3 border-t border-black/5 mt-6">
              <Button type="button" variant="admin-ghost" onClick={handleCloseDialog}>Cancel</Button>
              <Button type="submit" variant="admin-pill" disabled={saveMutation.isPending}>
                {saveMutation.isPending ? "Saving..." : (editingId ? "Update Experience" : "Add Experience")}
              </Button>
            </div>
          </form>
        </FormDialog>
      </div>
    </AdminLayout>
  );
}
