import { useState } from "react";
import AdminLayout from "./DashboardLayout";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { AdminPageHeader } from "@/components/admin/AdminPageHeader";
import { DataTable, Column } from "@/components/admin/DataTable";
import { FormDialog } from "@/components/admin/FormDialog";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { Button } from "@/components/ui/button";

const awardSchema = z.object({
  id: z.number().optional(),
  name: z.string().min(1, "Award name is required"),
  issuer: z.string().optional(),
  year: z.string().optional(),
});

type AwardFormValues = z.infer<typeof awardSchema>;

type Award = {
  id: number;
  name: string;
  issuer: string | null;
  year: string | null;
};

const inputClass = "w-full bg-black/5 border-transparent focus:bg-white focus:border-black/20 focus:ring-0 outline-none rounded-xl px-4 py-3.5 transition-colors text-[15px]";

export default function AwardsManager() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);

  const form = useForm<AwardFormValues>({
    resolver: zodResolver(awardSchema),
    defaultValues: { name: "", issuer: "", year: "" },
  });

  const { data: awards, isLoading } = useQuery<Award[]>({
    queryKey: ["awards"],
    queryFn: async () => {
      const res = await fetch("/api/awards");
      if (!res.ok) throw new Error("Network response was not ok");
      return res.json();
    },
  });

  const saveMutation = useMutation({
    mutationFn: async (data: AwardFormValues) => {
      const url = editingId ? `/api/awards/${editingId}` : "/api/awards";
      const method = editingId ? "PUT" : "POST";

      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Failed to save");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["awards"] });
      toast({ title: editingId ? "Award Updated" : "Award Added" });
      handleCloseDialog();
    },
    onError: () => {
      toast({ title: "Failed to save", variant: "destructive" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await fetch(`/api/awards/${id}`, { method: "DELETE" });
      if (!res.ok) throw new Error("Failed to delete");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["awards"] });
      toast({ title: "Deleted Successfully" });
    },
    onError: () => {
      toast({ title: "Failed to delete", variant: "destructive" });
    },
  });

  const handleOpenAdd = () => {
    setEditingId(null);
    form.reset({ name: "", issuer: "", year: "" });
    setIsDialogOpen(true);
  };

  const handleOpenEdit = (item: Award) => {
    setEditingId(item.id);
    form.reset({
      name: item.name,
      issuer: item.issuer || "",
      year: item.year || "",
    });
    setIsDialogOpen(true);
  };

  const handleCloseDialog = () => {
    setIsDialogOpen(false);
    setTimeout(() => {
      form.reset();
      setEditingId(null);
    }, 200);
  };

  const onSubmit = (data: AwardFormValues) => {
    saveMutation.mutate(data);
  };

  const columns: Column<Award>[] = [
    {
      header: "Award",
      cell: (item) => (
        <div>
          <span className="font-semibold text-black">{item.name}</span>
          {item.issuer && (
            <span className="block text-xs text-black/50 mt-0.5">{item.issuer}</span>
          )}
        </div>
      ),
    },
    {
      header: "Year",
      cell: (item) => (
        <span className="text-black/70 font-medium">{item.year || "—"}</span>
      ),
    },
  ];

  return (
    <AdminLayout>
      <div className="space-y-6">
        <AdminPageHeader 
          title="Honors & Awards" 
          description="Manage your hackathon wins, recognitions, and achievements."
          onAdd={handleOpenAdd}
          addButtonText="Add Award"
        />

        <DataTable 
          data={awards}
          columns={columns}
          isLoading={isLoading}
          onEdit={handleOpenEdit}
          onDelete={(id) => deleteMutation.mutate(id)}
          emptyMessage="No awards added yet."
        />

        <FormDialog 
          isOpen={isDialogOpen} 
          onOpenChange={(open) => !open && handleCloseDialog()} 
          title={editingId ? "Edit Award" : "Add Award"}
        >
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
            <div className="space-y-2">
              <label className="text-sm font-medium text-black/70 ml-1">Award Name</label>
              <input 
                {...form.register("name")}
                className={inputClass}
                placeholder="e.g. Winner — Ideal Analytics Challenge"
              />
              {form.formState.errors.name && <p className="text-red-500 text-xs ml-1">{form.formState.errors.name.message}</p>}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              <div className="space-y-2">
                <label className="text-sm font-medium text-black/70 ml-1">Issuer / Organization</label>
                <input 
                  {...form.register("issuer")}
                  className={inputClass}
                  placeholder="e.g. IIM Visakhapatnam"
                />
                <p className="text-xs text-black/40 ml-1">Organization that granted the award</p>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium text-black/70 ml-1">Year</label>
                <input 
                  {...form.register("year")}
                  className={inputClass}
                  placeholder="e.g. 2024"
                />
              </div>
            </div>

            <div className="pt-5 flex justify-end gap-3 border-t border-black/5 mt-6">
              <Button type="button" variant="admin-ghost" onClick={handleCloseDialog}>Cancel</Button>
              <Button type="submit" variant="admin-pill" disabled={saveMutation.isPending}>
                {saveMutation.isPending ? "Saving..." : (editingId ? "Update" : "Add Award")}
              </Button>
            </div>
          </form>
        </FormDialog>
      </div>
    </AdminLayout>
  );
}
