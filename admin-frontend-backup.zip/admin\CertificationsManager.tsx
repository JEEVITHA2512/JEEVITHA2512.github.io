import { useState } from "react";
import AdminLayout from "./DashboardLayout";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { AdminPageHeader } from "@/components/admin/AdminPageHeader";
import { DataTable, Column } from "@/components/admin/DataTable";
import { FormDialog } from "@/components/admin/FormDialog";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { Button } from "@/components/ui/button";

const certSchema = z.object({
  id: z.number().optional(),
  name: z.string().min(1, "Name is required"),
  issuer: z.string().min(1, "Issuer is required"),
  credentialId: z.string().optional(),
  credentialUrl: z.string().optional(),
  date: z.string().optional(),
  logoUrl: z.string().optional(),
});

type CertFormValues = z.infer<typeof certSchema>;

type Certification = {
  id: number;
  name: string;
  issuer: string;
  credentialId: string | null;
  credentialUrl: string | null;
  date: string | null;
  logoUrl: string | null;
};

const inputClass = "w-full bg-black/5 border-transparent focus:bg-white focus:border-black/20 focus:ring-0 outline-none rounded-xl px-4 py-3.5 transition-colors text-[15px]";

export default function CertificationsManager() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [isUploadingLogo, setIsUploadingLogo] = useState(false);

  const form = useForm<CertFormValues>({
    resolver: zodResolver(certSchema),
    defaultValues: { name: "", issuer: "", credentialId: "", credentialUrl: "", date: "", logoUrl: "" },
  });

  const { data: certifications, isLoading } = useQuery<Certification[]>({
    queryKey: ["certifications"],
    queryFn: async () => {
      const res = await fetch("/api/certifications");
      if (!res.ok) throw new Error("Network response was not ok");
      return res.json();
    },
  });

  const saveMutation = useMutation({
    mutationFn: async (data: CertFormValues) => {
      const url = editingId ? `/api/certifications/${editingId}` : "/api/certifications";
      const method = editingId ? "PUT" : "POST";

      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Failed to save");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["certifications"] });
      toast({ title: editingId ? "Certification Updated" : "Certification Added" });
      handleCloseDialog();
    },
    onError: () => {
      toast({ title: "Failed to save", variant: "destructive" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await fetch(`/api/certifications/${id}`, { method: "DELETE" });
      if (!res.ok) throw new Error("Failed to delete");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["certifications"] });
      toast({ title: "Deleted Successfully" });
    },
    onError: () => {
      toast({ title: "Failed to delete", variant: "destructive" });
    },
  });

  const handleLogoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || e.target.files.length === 0) return;
    
    const file = e.target.files[0];
    setIsUploadingLogo(true);

    try {
      const query = new URLSearchParams({
        filename: file.name,
        contentType: file.type || "application/octet-stream",
      });

      const uploadRes = await fetch(`/api/storage/upload?${query.toString()}`, {
        method: "POST",
        headers: { "Content-Type": file.type || "application/octet-stream" },
        body: file,
      });

      if (!uploadRes.ok) throw new Error("Failed to upload image");
      const { publicUrl } = await uploadRes.json();

      form.setValue("logoUrl", publicUrl);
      toast({ title: "Logo Uploaded Successfully" });

    } catch (err) {
      toast({ title: "Upload Failed", variant: "destructive" });
      console.error(err);
    } finally {
      setIsUploadingLogo(false);
    }
  };

  const handleOpenAdd = () => {
    setEditingId(null);
    form.reset({ name: "", issuer: "", credentialId: "", credentialUrl: "", date: "", logoUrl: "" });
    setIsDialogOpen(true);
  };

  const handleOpenEdit = (item: Certification) => {
    setEditingId(item.id);
    form.reset({
      name: item.name,
      issuer: item.issuer,
      credentialId: item.credentialId || "",
      credentialUrl: item.credentialUrl || "",
      date: item.date || "",
      logoUrl: item.logoUrl || "",
    });
    setIsDialogOpen(true);
  };

  const handleCloseDialog = () => {
    setIsDialogOpen(false);
    setTimeout(() => {
      form.reset();
      setEditingId(null);
    }, 200);
  };

  const onSubmit = (data: CertFormValues) => {
    saveMutation.mutate(data);
  };

  const columns: Column<Certification>[] = [
    {
      header: "Logo",
      cell: (item) => {
        const initial = item.issuer ? item.issuer.charAt(0).toUpperCase() : "?";
        return (
          <div className="w-8 h-8 rounded-lg bg-black/5 overflow-hidden flex items-center justify-center p-0.5 border border-black/5">
            {item.logoUrl ? (
              <img src={item.logoUrl} alt={item.issuer} className="w-full h-full object-contain" />
            ) : (
              <span className="text-[11px] font-extrabold text-black/35">{initial}</span>
            )}
          </div>
        );
      },
    },
    {
      header: "Certification",
      cell: (item) => (
        <div>
          <span className="font-semibold text-black">{item.name}</span>
          {item.credentialId && (
            <span className="block text-xs text-black/40 mt-0.5">ID: {item.credentialId}</span>
          )}
        </div>
      ),
    },
    { header: "Issuer", accessorKey: "issuer" },
    {
      header: "Date",
      cell: (item) => (
        <span className="text-black/70 font-medium">{item.date || "—"}</span>
      ),
    },
  ];

  return (
    <AdminLayout>
      <div className="space-y-6">
        <AdminPageHeader 
          title="Certifications" 
          description="Manage your professional certifications and licenses."
          onAdd={handleOpenAdd}
          addButtonText="Add Certification"
        />

        <DataTable 
          data={certifications}
          columns={columns}
          isLoading={isLoading}
          onEdit={handleOpenEdit}
          onDelete={(id) => deleteMutation.mutate(id)}
          emptyMessage="No certifications added yet."
        />

        <FormDialog 
          isOpen={isDialogOpen} 
          onOpenChange={(open) => !open && handleCloseDialog()} 
          title={editingId ? "Edit Certification" : "Add Certification"}
        >
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
            <div className="space-y-2">
              <label className="text-sm font-medium text-black/70 ml-1">Certification Name</label>
              <input 
                {...form.register("name")}
                className={inputClass}
                placeholder="e.g. AWS Certified Solutions Architect"
              />
              {form.formState.errors.name && <p className="text-red-500 text-xs ml-1">{form.formState.errors.name.message}</p>}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              <div className="space-y-2">
                <label className="text-sm font-medium text-black/70 ml-1">Issuing Organization</label>
                <input 
                  {...form.register("issuer")}
                  className={inputClass}
                  placeholder="e.g. Amazon Web Services (AWS)"
                />
                {form.formState.errors.issuer && <p className="text-red-500 text-xs ml-1">{form.formState.errors.issuer.message}</p>}
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium text-black/70 ml-1">Date Issued</label>
                <input 
                  {...form.register("date")}
                  className={inputClass}
                  placeholder="e.g. Jan 2025"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              <div className="space-y-2">
                <label className="text-sm font-medium text-black/70 ml-1">Credential ID</label>
                <input 
                  {...form.register("credentialId")}
                  className={inputClass}
                  placeholder="e.g. ABC-123-XYZ"
                />
                <p className="text-xs text-black/40 ml-1">Your unique credential identifier</p>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium text-black/70 ml-1">Credential URL</label>
                <input 
                  {...form.register("credentialUrl")}
                  className={inputClass}
                  placeholder="e.g. https://credly.com/badges/..."
                />
                <p className="text-xs text-black/40 ml-1">Adds a "Verify" link on the portfolio</p>
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-black/70 ml-1">Custom Logo (Optional)</label>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-black/5 overflow-hidden flex items-center justify-center border border-black/10 shrink-0">
                  {form.watch("logoUrl") ? (
                    <img src={form.watch("logoUrl")} className="w-full h-full object-contain" />
                  ) : (
                    <span className="text-sm font-bold text-black/30">Auto</span>
                  )}
                </div>
                <div className="flex-1">
                  <input 
                    type="file" 
                    accept="image/*" 
                    onChange={handleLogoUpload} 
                    className="hidden" 
                    id="logo-upload"
                  />
                  <label htmlFor="logo-upload">
                    <Button type="button" variant="admin-ghost" className="cursor-pointer" asChild>
                      <span>
                        {isUploadingLogo ? "Uploading..." : form.watch("logoUrl") ? "Change Logo" : "Upload Custom Logo"}
                      </span>
                    </Button>
                  </label>
                  {form.watch("logoUrl") && (
                    <Button 
                      type="button" 
                      variant="destructive" 
                      size="sm" 
                      className="ml-2 py-1 px-3 h-auto text-xs"
                      onClick={() => form.setValue("logoUrl", "")}
                    >
                      Clear
                    </Button>
                  )}
                  <p className="text-[11px] text-black/40 mt-1">If not uploaded, the portfolio will automatically fetch it from brand CDNs based on the organization name.</p>
                </div>
              </div>
            </div>

            <div className="pt-5 flex justify-end gap-3 border-t border-black/5 mt-6">
              <Button type="button" variant="admin-ghost" onClick={handleCloseDialog}>Cancel</Button>
              <Button type="submit" variant="admin-pill" disabled={saveMutation.isPending}>
                {saveMutation.isPending ? "Saving..." : (editingId ? "Update" : "Add Certification")}
              </Button>
            </div>
          </form>
        </FormDialog>
      </div>
    </AdminLayout>
  );
}

