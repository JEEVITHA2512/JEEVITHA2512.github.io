import { neon } from '@neondatabase/serverless';
import * as dotenv from 'dotenv';

dotenv.config();

async function migrate() {
  if (!process.env.DATABASE_URL) {
    throw new Error("DATABASE_URL is not set");
  }

  const sql = neon(process.env.DATABASE_URL);

  console.log("Adding credential_id, credential_url, date columns to certifications table...");
  await sql`ALTER TABLE certifications ADD COLUMN IF NOT EXISTS credential_id VARCHAR(255)`;
  await sql`ALTER TABLE certifications ADD COLUMN IF NOT EXISTS credential_url TEXT`;
  await sql`ALTER TABLE certifications ADD COLUMN IF NOT EXISTS date VARCHAR(255)`;

  console.log("Migration complete!");
  process.exit(0);
}

migrate().catch((err) => {
  console.error("Migration failed:", err);
  process.exit(1);
});
