import { db } from "./index";
import { profile } from "./schema";

async function run() {
  console.log("Updating avatar URL in database...");
  await db.update(profile).set({
    avatarUrl: "https://res.cloudinary.com/dfdehn9pr/image/upload/v1780377578/Jeevitha_qid9vc.png"
  });
  console.log("Avatar URL updated successfully!");
  process.exit(0);
}

run().catch(console.error);
