import { db } from "./index";
import { profile, experiences, education, certifications, awards, projects, publications, patents } from "./schema";

async function seed() {
  console.log("Seeding database...");

  // Deletions to prevent duplicates
  console.log("Cleaning up existing data...");
  await db.delete(profile);
  await db.delete(experiences);
  await db.delete(education);
  await db.delete(certifications);
  await db.delete(awards);
  await db.delete(projects);
  await db.delete(publications);
  await db.delete(patents);

  // Profile
  console.log("Seeding profile...");
  await db.insert(profile).values({
    name: "Jeevitha Murugan",
    title: "Data Scientist & Generative AI Engineer",
    tagline: "Engineering the Future with Generative AI & Data | AWS Community Builder (AI) | Data Scientist @ BigTapp",
    about: "Hey there! 👋 \n\nI'm Jeevitha Murugan and I work as a Data Scientist at BigTapp Analytics. My work spans insurance, logistics, and banking (commercial, corporate, and investment). I focus on designing and implementing AI-driven automation within core business pipelines, especially using Agentic AI and LLM systems for use cases like intelligent document processing, decision support, and workflow automation. I’m also involved in technical pre-sales, where I bridge AI capabilities with business needs, shape solution architectures, and help bring scalable, production-ready systems to life.\n\nI’m always open to connecting with people building in AI, data, and enterprise systems. As an AWS Community Builder (AI Engineering), speaker, blogger, and mentor, I’ve guided 450+ students in AWS foundational certifications, guided 25+ Cloud Clubs across India and enjoy sharing practical insights from real-world AI systems. I was recognized with the AWS APJC Community Award (Customer Obsession category), along with attending AWS re:Invent 2025. I hold 2× AWS, 5× Azure, 2× Dataiku, and 2× Databricks certifications.\n\nIf you're exploring AI in finance, automation, agentic systems, AI Security or AWS Community, feel free to connect or start a conversation.\n\n📫 Contact Details : jeevithamurugan.2512@gmail.com",
    techSkills: [
      "Python", "TensorFlow", "PyTorch", "LangChain", "Rasa", "MLflow", 
      "Azure", "AWS", "Hugging Face", "Agentic AI", "Apache Spark", "CrewAI", 
      "FastAPI", "Streamlit", "ClickHouse", "SQL", "Elasticsearch", "OpenTelemetry"
    ],
    avatarUrl: "https://res.cloudinary.com/dfdehn9pr/image/upload/v1780377578/Jeevitha_qid9vc.png",
    yearsExperience: "2+",
    studentsMentored: "450+",
    github: "https://github.com/jeevithamurugan",
    linkedin: "https://www.linkedin.com/in/jeevitha-murugan-357979223",
    email: "jeevithamurugan.2512@gmail.com",
    googleScholarUrl: "https://scholar.google.com/citations?user=sNlZI-4AAAAJ&hl=en",
    location: "Chennai, India",
    role: "GenAI Engineer @ BigTapp",
    community: "AWS Community Builder",
    experienceTitle: "Experience",
    experienceSub: "Full-time & Internship work",
    mentorshipTitle: "Mentorship",
    mentorshipSub: "AWS Clubs & User Groups guided",
  });

  // Experiences
  console.log("Seeding experiences...");
  await db.insert(experiences).values([
    {
      role: "Data Scientist",
      company: "BigTapp Analytics",
      companyDescription: "Cognitive Data & AI Services",
      date: "Apr 2026 - Present",
      duration: "3 mos",
      location: "Chennai, Tamil Nadu, India · On-site",
      highlights: [
        "Work on Generative AI solutions across insurance, logistics, and banking (commercial, corporate, and investment).",
        "Focus on designing and implementing Agentic AI and LLM-based systems for real-world enterprise use cases like document processing.",
        "Collaborate in technical pre-sales to translate business requirements into scalable AI solutions and architecture designs."
      ],
      skills: ["Agentic AI", "Technical Presales", "Data Science", "Generative AI"]
    },
    {
      role: "Generative AI & Data Science Engineer",
      company: "BigTapp Analytics",
      companyDescription: "Cognitive Data & AI Services",
      date: "Jun 2025 - Present",
      duration: "1 yr 1 mo",
      location: "Chennai, Tamil Nadu, India · On-site",
      highlights: [
        "Designed and implemented Agentic AI and LLM-based reasoning systems for core business workflows.",
        "Developed intelligent document processing pipelines combining OCR and LLMs for automated data extraction and validation.",
        "Built RAG-based architectures and decision support systems for financial log analysis and incident investigation.",
        "Integrated cloud-native AI solutions using AWS Bedrock and Elastic technologies in enterprise architectures."
      ],
      skills: ["Generative AI", "Agentic AI", "LLM", "RAG", "Technical Presales"]
    },
    {
      role: "Software Engineer Intern",
      company: "Blackstraw",
      companyDescription: "AI & Software Engineering",
      date: "Sep 2024 - Jun 2025",
      duration: "10 mos",
      location: "Chennai, Tamil Nadu, India · On-site",
      highlights: [
        "Built autonomous multi-agent pipelines using CrewAI for code migration and refactoring tasks with inter-agent memory sharing and task delegation.",
        "Integrated with OpenLit to provide real-time traceability and observability of agent behaviors.",
        "Designed and deployed a full-stack analytics pipeline using Microsoft's Fabric Analytics, utilizing Dataflows and Power BI dashboards to reduce manual analysis cycles by 60%.",
        "Used Kusto Query Language (KQL) to analyze Azure Bot Framework logs to identify key drop-off points, latency issues, and fine-tune bot flows."
      ],
      skills: ["CrewAI", "Fabric Analytics", "Power BI", "KQL", "Azure", "Agentic AI", "OpenLit"]
    },
    {
      role: "Intern - Data Scientist",
      company: "Lifease Solutions LLP",
      companyDescription: "Health & Wellness Tech",
      date: "Jul 2023 - Oct 2023",
      duration: "4 mos",
      location: "Noida, Uttar Pradesh, India · Remote",
      highlights: [
        "Processed raw audio inputs using Librosa, SoundFile, pydub, and PyAudio, extracting Mel-spectrograms, STFT, and MFCC features for feature engineering.",
        "Developed and trained CNN, Bi-LSTM, and AutoEncoder architectures using TensorFlow and PyTorch for audio denoising tasks.",
        "Integrated Audo AI's pretrained APIs for production-grade noise suppression and compared against in-house models for latency and accuracy.",
        "Explored TTS synthesis using pyttsx3 and validated naturalness of generated speech against transcripts."
      ],
      skills: ["Python", "TensorFlow", "PyTorch", "Librosa", "Audio AI", "Deep Learning"]
    },
    {
      role: "Developer Intern",
      company: "Tactii (formerly TalentAccurate)",
      companyDescription: "HR & Talent Tech",
      date: "Jan 2022 - Oct 2022",
      duration: "10 mos",
      location: "Toronto, Ontario, Canada · Remote",
      highlights: [
        "Built custom NLU pipelines for domain-specific chatbots using Rasa and Spacy, enhancing intent classification accuracy with synonym mapping and fallback logic.",
        "Deployed ML models with Flask APIs and Streamlit dashboards, including an sentiment analysis tool with prediction breakdowns.",
        "Designed schema models for chatbot session logging and user feedback using ClickHouse for high-throughput analytical queries in performance dashboards.",
        "Participated in internal Python mentoring sessions and peer reviews for junior interns."
      ],
      skills: ["Python", "Rasa", "Spacy", "Flask", "Streamlit", "ClickHouse", "SQL"]
    }
  ]);

  // Education
  console.log("Seeding education...");
  await db.insert(education).values([
    {
      degree: "Bachelor of Technology - BTech",
      field: "Artificial Intelligence and Data Science",
      institution: "St. Joseph's College Of Engineering",
      institutionType: "Engineering College · Autonomous",
      date: "Nov 2021 – May 2025",
      description: "Pursued intensive academic coursework in Artificial Intelligence and Data Science. Major curriculum areas covered programming languages, data structures, database design, and machine learning theory. Participated in technical hackathons, laboratory experiments, and project design evaluations to apply software engineering and analytical approaches to real-world datasets."
    },
    {
      degree: "12th equivalent grade",
      field: "Biology, General",
      institution: "St. Johns Sr. Sec. School & Junior College",
      institutionType: "Senior Secondary School",
      date: "2006 – 2021",
      description: "Completed foundational education with a focus on science and biology. Built a strong academic base in mathematics, physics, and computer applications."
    }
  ]);

  // Certifications
  console.log("Seeding certifications...");
  await db.insert(certifications).values([
    { name: "AWS Certified Generative AI Developer - Professional", issuer: "Amazon Web Services (AWS)" },
    { name: "Databricks Certified Machine Learning Professional", issuer: "Databricks" },
    { name: "Cast AI APA Hero - Cloud Native & Application Performance Automation", issuer: "Cast AI" },
    { name: "Dataiku Generative AI Practitioner", issuer: "Dataiku" },
    { name: "Databricks Certified Data Engineer Associate", issuer: "Databricks" },
    { name: "AWS Certified AI Practitioner", issuer: "Amazon Web Services (AWS)" },
    { name: "Microsoft Certified: Azure Data Engineer Associate", issuer: "Microsoft" },
    { name: "AWS Cloud Clubs Certified Instructor", issuer: "AWS User Groups" },
    { name: "Certified Python Developer Associate", issuer: "ISO 14001 Certification" },
    { name: "Microsoft Certified: Azure Fundamentals", issuer: "Microsoft" },
    { name: "Oracle Cloud Infrastructure 2023 AI Certified Foundations Associate", issuer: "Oracle" },
    { name: "Google Cybersecurity Certificate", issuer: "Coursera" },
    { name: "Microsoft Certified: Fabric Analytics Engineer Associate", issuer: "Microsoft" },
    { name: "Microsoft Certified: Azure AI Engineer Associate", issuer: "Microsoft" },
    { name: "Microsoft Certified: Azure AI Fundamentals", issuer: "Microsoft" },
    { name: "Cambridge Business English Certification", issuer: "Cambridge University Press & Assessment" },
    { name: "IBM Data Science Professional Certificate", issuer: "IBM" }
  ]);

  // Awards
  console.log("Seeding awards...");
  await db.insert(awards).values([
    { name: "AWS Community Awards APJC — Customer Obsession Category", issuer: "Amazon Web Services", year: "2025" },
    { name: "Winner — Ideal Analytics Challenge", issuer: "IIM Visakhapatnam", year: "2024" },
    { name: "SIH Finalist", issuer: "AICTE-MIC, Government of India", year: "2024" },
    { name: "Winner — Case Study Competition", issuer: "Anna University", year: "2024" },
    { name: "3rd Place — Hack-a-Cloud", issuer: "AWS Cloud Club", year: "2023" },
    { name: "Winner — UI Path Hack-a-bot", issuer: "UiPath Community", year: "2023" },
    { name: "2nd Runner Up — Cosmic Innovation Challenge (Microgravity Track)", issuer: "IIT Madras", year: "2023" }
  ]);

  // Projects
  console.log("Seeding projects...");
  await db.insert(projects).values([
    {
      title: "Multi-Agent Code Migration Pipeline",
      description: "Autonomous multi-agent system using CrewAI for code migration and refactoring tasks, with inter-agent memory sharing, task delegation, and OpenLit observability integration.",
      tags: ["CrewAI", "Python", "Agentic AI", "OpenLit", "LangChain"],
      link: "#"
    },
    {
      title: "Fabric Analytics Sales Dashboard",
      description: "Full-stack analytics pipeline using Microsoft Fabric Analytics with Dataflows transformation logic and Power BI dashboards, reducing manual analysis cycles by 60%.",
      tags: ["Microsoft Fabric", "Power BI", "Dataflows", "Azure", "KQL"],
      link: "#"
    },
    {
      title: "Audio Denoising Deep Learning Models",
      description: "CNN, Bi-LSTM, and AutoEncoder architectures for audio denoising using TensorFlow and PyTorch. Benchmarked on clean-noisy pair datasets to improve Signal-to-Noise Ratio (SNR).",
      tags: ["TensorFlow", "PyTorch", "torchaudio", "Librosa", "Deep Learning"],
      link: "#"
    },
    {
      title: "Domain-Specific NLU Chatbot",
      description: "Custom NLU pipelines for domain-specific chatbots using Rasa and SpaCy, with enhanced intent classification, entity synonym mapping, and fallback logic.",
      tags: ["Rasa", "SpaCy", "NLP", "Flask", "Python"],
      link: "#"
    },
    {
      title: "Smart Sprinkler System (Patent)",
      description: "IoT-based sprinkler system leveraging machine learning and heat mapping for precision irrigation, minimizing water waste through intelligent sensor-driven automation.",
      tags: ["Machine Learning", "IoT", "Python", "Embedded Systems"],
      link: "#"
    },
    {
      title: "Multilingual Audio to Braille Translator (Patent)",
      description: "AI-powered system incorporating multilingual audio transcription and cloud computing to convert spoken language into Braille, enabling accessibility for visually impaired users.",
      tags: ["Speech-to-Text", "NLP", "Cloud Computing", "AI", "Python"],
      link: "#"
    }
  ]);

  // Publications
  console.log("Seeding publications...");
  await db.insert(publications).values([
    {
      title: "Data-driven machine learning models for risk stratification and prediction of Emergence Delirium in pediatric patients underwent tonsillectomy/adenotonsillectomy",
      publisher: "Annali Italiani di Chirurgia 95 (5), 944-955, 2024",
      description: "Authors: A Simonini, J Murugan, A Vittori, R Pallotto, EG Bignami, MG Calevo, .... Developed and benchmarked machine learning models for clinical risk stratification to predict emergence delirium in pediatric patients post-surgery.",
      link: "https://scholar.google.com/citations?view_op=view_citation&hl=en&user=sNlZI-4AAAAJ&citation_for_view=sNlZI-4AAAAJ:u5HHmVD_uO8C",
      date: "2024"
    },
    {
      title: "Optimizing OCR Model Performance: A Comparative Study of Backbone Architectures and Hyperparameter Tuning",
      publisher: "CCIS, SPELLL Conference, 2024",
      description: "Authors: M Jeevitha, R DhanushKumar, S Harisudhan, GB Vishal, M Karthi, .... Published research on comparative study of backbone OCR models and tuning parameters for low-resource languages.",
      link: "https://scholar.google.com/citations?view_op=view_citation&hl=en&user=sNlZI-4AAAAJ&citation_for_view=sNlZI-4AAAAJ:d1gkVwhDpl0C",
      date: "2024"
    },
    {
      title: "Payday loans--blessing or growth suppressor? Machine Learning Analysis",
      publisher: "arXiv preprint arXiv:2205.15320, 2022",
      description: "Authors: R Mahadevan, S Richard, KH Kumar, J Murugan, S Kannan, .... Applied machine learning techniques to analyze the financial and socioeconomic impact of payday lending.",
      link: "https://scholar.google.com/citations?view_op=view_citation&hl=en&user=sNlZI-4AAAAJ&citation_for_view=sNlZI-4AAAAJ:u-x6o8ySG0sC",
      date: "2022"
    }
  ]);

  // Patents
  console.log("Seeding patents...");
  await db.insert(patents).values([
    {
      title: "Smart Sprinkler system : Leveraging Machine Learning and IoT for heat mapping",
      description: "Patented IoT-based smart irrigation system (Application: 202341052464) using ML algorithms and heat mapping to intelligently control sprinklers, optimizing water usage while ensuring effective coverage.",
      link: "https://patents.google.com/patent/IN202341052464A/en",
      date: "2023"
    },
    {
      title: "Multilingual Audio to Braille Translator System Incorporating AI Transcription and Cloud Computing",
      description: "Patented assistive technology system converting multilingual audio input to Braille output using AI transcription and cloud infrastructure, enhancing accessibility for visually impaired individuals.",
      link: "https://patents.google.com/?inventor=Jeevitha+Murugan",
      date: "2024"
    }
  ]);

  console.log("Database seeding completed!");
  process.exit(0);
}

seed().catch(console.error);
