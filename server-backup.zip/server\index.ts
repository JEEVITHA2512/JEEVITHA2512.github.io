import express from "express";
import cors from "cors";
import cookieParser from "cookie-parser";
import * as dotenv from "dotenv";
import { db } from "./db/index";
import { experiences, projects, profile, education, certifications, awards, blogs, publications, patents } from "./db/schema";
import { eq } from "drizzle-orm";
import jwt from "jsonwebtoken";
import { S3Client, PutObjectCommand } from "@aws-sdk/client-s3";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";
import Parser from "rss-parser";
import path from "path";
import { fileURLToPath } from "url";

import { cleanPayload } from "./utils";

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;
const isProduction = process.env.NODE_ENV === "production";

function getRequiredEnv(name: string, fallback: string) {
  const value = process.env[name];
  if (isProduction && !value) {
    throw new Error(`${name} is required in production`);
  }
  return value || fallback;
}

const JWT_SECRET = getRequiredEnv("JWT_SECRET", "default-secret");
const ADMIN_USERNAME = getRequiredEnv("ADMIN_USERNAME", "admin");
const ADMIN_PASSWORD = getRequiredEnv("ADMIN_PASSWORD", "password123");
const CORS_ORIGIN = process.env.CORS_ORIGIN;

function getRouteId(id: string | string[]) {
  return parseInt(Array.isArray(id) ? id[0] : id, 10);
}

// R2 Setup
const r2Client = new S3Client({
  region: "auto",
  endpoint: `https://${process.env.R2_ACCOUNT_ID}.r2.cloudflarestorage.com`,
  credentials: {
    accessKeyId: process.env.R2_ACCESS_KEY_ID || "",
    secretAccessKey: process.env.R2_SECRET_ACCESS_KEY || "",
  },
});

app.use(cors({ origin: CORS_ORIGIN || true, credentials: true }));
app.use(express.json());
app.use(cookieParser());

// Security Headers Middleware
app.use((req, res, next) => {
  res.setHeader("X-Frame-Options", "DENY");
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
  res.setHeader("X-XSS-Protection", "1; mode=block");
  res.setHeader("Strict-Transport-Security", "max-age=31536000; includeSubDomains");
  res.setHeader(
    "Content-Security-Policy",
    "default-src 'self'; script-src 'self' 'unsafe-inline' 'unsafe-eval'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com https://db.onlinewebfonts.com; font-src 'self' data: https://fonts.gstatic.com https://db.onlinewebfonts.com; img-src 'self' data: blob: *; connect-src 'self' *"
  );
  next();
});

app.use((req, res, next) => {
  console.log(`[REQUEST] ${req.method} ${req.url}`);
  next();
});

// Auth Middleware
const authenticateToken = (req: express.Request, res: express.Response, next: express.NextFunction) => {
  const token = req.cookies.admin_token;
  if (!token) return res.status(401).json({ message: "Unauthorized" });

  jwt.verify(token, JWT_SECRET, (err: any, user: any) => {
    if (err) return res.status(403).json({ message: "Forbidden" });
    next();
  });
};

// --- AUTH ENDPOINTS ---
app.post("/api/auth/login", (req, res) => {
  const { username, password } = req.body;
  console.log(`[LOGIN ATTEMPT] Username: "${username}". Target: "${ADMIN_USERNAME}"`);
  
  const isMatch = username === ADMIN_USERNAME && 
    (password === ADMIN_PASSWORD ||
     (!isProduction && (password === "password" || password === "password123")));

  if (isMatch) {
    const token = jwt.sign({ username }, JWT_SECRET, { expiresIn: "24h" });
    res.cookie("admin_token", token, {
      httpOnly: true,
      secure: isProduction,
      sameSite: "strict",
      maxAge: 24 * 60 * 60 * 1000,
    });
    res.json({ success: true });
  } else {
    console.log(`[LOGIN FAILED] Invalid credentials for username: "${username}"`);
    res.status(401).json({ success: false, message: "Invalid credentials" });
  }
});

app.post("/api/auth/logout", (req, res) => {
  res.clearCookie("admin_token");
  res.json({ success: true });
});

app.get("/api/auth/me", authenticateToken, (req, res) => {
  res.json({ success: true, username: ADMIN_USERNAME });
});

// --- CONTENT ENDPOINTS ---

// GET All Experiences
app.get("/api/experiences", async (req, res) => {
  const data = await db.select().from(experiences).orderBy(experiences.id);
  res.json(data);
});

// POST Experience
app.post("/api/experiences", authenticateToken, async (req, res) => {
  const body = cleanPayload(req.body);
  const result = await db.insert(experiences).values(body).returning();
  res.json(result[0]);
});

// PUT Experience
app.put("/api/experiences/:id", authenticateToken, async (req, res) => {
  const id = getRouteId(req.params.id);
  const body = cleanPayload(req.body, true);
  const result = await db.update(experiences).set(body).where(eq(experiences.id, id)).returning();
  res.json(result[0]);
});

// DELETE Experience
app.delete("/api/experiences/:id", authenticateToken, async (req, res) => {
  const id = getRouteId(req.params.id);
  await db.delete(experiences).where(eq(experiences.id, id));
  res.json({ success: true });
});

// Helper function to create CRUD routes for a given table
function createCRUDRoutes(path: string, table: any) {
  // GET All
  app.get(`/api/${path}`, async (req, res) => {
    const data = await db.select().from(table).orderBy(table.id);
    res.json(data);
  });
  // POST
  app.post(`/api/${path}`, authenticateToken, async (req, res) => {
    const body = cleanPayload(req.body);
    const result = await db.insert(table).values(body).returning() as any[];
    res.json(result[0]);
  });
  // PUT
  app.put(`/api/${path}/:id`, authenticateToken, async (req, res) => {
    const id = getRouteId(req.params.id);
    const body = cleanPayload(req.body, true);
    const result = await db.update(table).set(body).where(eq(table.id, id)).returning();
    res.json(result[0]);
  });
  // DELETE
  app.delete(`/api/${path}/:id`, authenticateToken, async (req, res) => {
    const id = getRouteId(req.params.id);
    await db.delete(table).where(eq(table.id, id));
    res.json({ success: true });
  });
}

createCRUDRoutes("projects", projects);
createCRUDRoutes("education", education);
createCRUDRoutes("certifications", certifications);
createCRUDRoutes("awards", awards);
createCRUDRoutes("publications", publications);
createCRUDRoutes("patents", patents);

app.get("/api/blogs", async (req, res) => {
  try {
    const data = await db.select().from(profile).limit(1);
    const blogRssUrl = data[0]?.blogRssUrl;
    
    if (!blogRssUrl) {
      return res.json([]);
    }

    const parser = new Parser();
    const feed = await parser.parseURL(blogRssUrl);
    
    // Map the feed items to match our expected blog structure
    const blogsData = feed.items.map((item: any, index: number) => ({
      id: index,
      title: item.title || "Untitled",
      description: item.contentSnippet || item.content || "No description available.",
      link: item.link || "#",
      date: item.pubDate || new Date().toISOString()
    }));
    
    res.json(blogsData);
  } catch (error) {
    console.error("Error fetching RSS feed:", error);
    res.json([]);
  }
});

// Profile is a singleton (usually id=1)
app.get("/api/profile", async (req, res) => {
  const data = await db.select().from(profile).limit(1);
  res.json(data[0] || null);
});
app.put("/api/profile", authenticateToken, async (req, res) => {
  const body = cleanPayload(req.body, true);
  const existing = await db.select().from(profile).limit(1);
  if (existing.length === 0) {
    const insertBody = { ...cleanPayload(req.body), updatedAt: new Date() };
    const result = await db.insert(profile).values(insertBody).returning();
    res.json(result[0]);
  } else {
    const result = await db.update(profile).set(body).where(eq(profile.id, existing[0].id)).returning();
    res.json(result[0]);
  }
});

// --- STORAGE ENDPOINTS ---
app.post(
  "/api/storage/upload",
  authenticateToken,
  express.raw({ type: () => true, limit: "10mb" }),
  async (req, res) => {
    try {
      const filename = typeof req.query.filename === "string" ? req.query.filename : "upload.bin";
      const contentType = typeof req.query.contentType === "string" ? req.query.contentType : "application/octet-stream";

      if (!Buffer.isBuffer(req.body) || req.body.length === 0) {
        return res.status(400).json({ error: "File body is required" });
      }

      const safeFilename = path.basename(filename).replace(/[^a-zA-Z0-9._-]/g, "_");
      const key = `${Date.now()}-${safeFilename}`;

      const command = new PutObjectCommand({
        Bucket: process.env.R2_BUCKET_NAME,
        Key: key,
        Body: req.body,
        ContentType: contentType,
      });

      await r2Client.send(command);
      const publicUrl = `${process.env.R2_PUBLIC_URL}/${key}`;

      res.json({ publicUrl });
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: "Failed to upload file" });
    }
  }
);

app.post("/api/storage/presigned-url", authenticateToken, async (req, res) => {
  try {
    const { filename, contentType } = req.body;
    const key = `${Date.now()}-${filename}`;
    
    const command = new PutObjectCommand({
      Bucket: process.env.R2_BUCKET_NAME,
      Key: key,
      ContentType: contentType,
    });

    const url = await getSignedUrl(r2Client, command, { expiresIn: 3600 });
    const publicUrl = `${process.env.R2_PUBLIC_URL}/${key}`;

    res.json({ uploadUrl: url, publicUrl });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Failed to generate presigned URL" });
  }
});

if (isProduction) {
  const __dirname = path.dirname(fileURLToPath(import.meta.url));
  const clientDist = path.resolve(__dirname, "../public");

  app.use(express.static(clientDist));
  app.get(/.*/, (_req, res) => {
    res.sendFile(path.join(clientDist, "index.html"));
  });
}

// Server Initialization
if (process.env.NODE_ENV !== "test") {
  app.listen(PORT, () => {
    console.log(`Server listening on port ${PORT}`);
  });
}

export default app;
