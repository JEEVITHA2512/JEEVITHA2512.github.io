import { neon } from '@neondatabase/serverless';
import * as dotenv from 'dotenv';

dotenv.config();

async function migrate() {
  if (!process.env.DATABASE_URL) {
    throw new Error("DATABASE_URL is not set");
  }

  const sql = neon(process.env.DATABASE_URL);

  console.log("Adding issuer and year columns to awards table...");
  await sql`ALTER TABLE awards ADD COLUMN IF NOT EXISTS issuer VARCHAR(255)`;
  await sql`ALTER TABLE awards ADD COLUMN IF NOT EXISTS year VARCHAR(50)`;

  console.log("Backfilling issuer from existing name patterns...");

  // Extract issuer from parentheses pattern: "Award Name (Issuer)"
  await sql`
    UPDATE awards
    SET
      issuer = COALESCE(issuer,
        CASE
          WHEN name ~ '\(([^)]+)\)$' THEN substring(name FROM '\(([^)]+)\)$')
          ELSE NULL
        END
      )
    WHERE issuer IS NULL
  `;

  console.log("Migration complete!");
  process.exit(0);
}

migrate().catch((err) => {
  console.error("Migration failed:", err);
  process.exit(1);
});
