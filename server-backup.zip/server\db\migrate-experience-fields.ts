import { neon } from '@neondatabase/serverless';
import * as dotenv from 'dotenv';

dotenv.config();

async function migrate() {
  if (!process.env.DATABASE_URL) {
    throw new Error("DATABASE_URL is not set");
  }

  const sql = neon(process.env.DATABASE_URL);

  console.log("Adding company_description column to experiences table...");
  await sql`ALTER TABLE experiences ADD COLUMN IF NOT EXISTS company_description VARCHAR(255)`;

  console.log("Backfilling company_description for existing rows...");
  await sql`
    UPDATE experiences
    SET company_description = CASE
      WHEN company ILIKE '%BigTapp%' THEN 'Cognitive Data & AI Services'
      WHEN company ILIKE '%Blackstraw%' THEN 'AI & Software Engineering'
      WHEN company ILIKE '%Lifease%' THEN 'Health & Wellness Tech'
      WHEN company ILIKE '%Tactii%' THEN 'HR & Talent Tech'
      ELSE company
    END
    WHERE company_description IS NULL
  `;

  console.log("Migration complete!");
  process.exit(0);
}

migrate().catch((err) => {
  console.error("Migration failed:", err);
  process.exit(1);
});
