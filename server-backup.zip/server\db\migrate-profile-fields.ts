import { neon } from '@neondatabase/serverless';
import * as dotenv from 'dotenv';

dotenv.config();

async function migrate() {
  if (!process.env.DATABASE_URL) {
    throw new Error("DATABASE_URL is not set");
  }

  const sql = neon(process.env.DATABASE_URL);

  console.log("Adding location, role, community columns to profile table...");

  await sql`ALTER TABLE profile ADD COLUMN IF NOT EXISTS location VARCHAR(255)`;
  await sql`ALTER TABLE profile ADD COLUMN IF NOT EXISTS role VARCHAR(255)`;
  await sql`ALTER TABLE profile ADD COLUMN IF NOT EXISTS community VARCHAR(255)`;

  console.log("Columns added successfully.");

  console.log("Backfilling default values...");
  await sql`
    UPDATE profile
    SET
      location = COALESCE(location, 'Chennai, India'),
      role = COALESCE(role, 'GenAI Engineer @ BigTapp'),
      community = COALESCE(community, 'AWS Community Builder')
    WHERE location IS NULL OR role IS NULL OR community IS NULL
  `;

  console.log("Migration complete!");
  process.exit(0);
}

migrate().catch((err) => {
  console.error("Migration failed:", err);
  process.exit(1);
});
