import { pgTable, serial, text, varchar, timestamp, jsonb, boolean } from "drizzle-orm/pg-core";

export const experiences = pgTable("experiences", {
  id: serial("id").primaryKey(),
  role: varchar("role", { length: 255 }).notNull(),
  company: varchar("company", { length: 255 }).notNull(),
  companyDescription: varchar("company_description", { length: 255 }),
  date: varchar("date", { length: 255 }).notNull(),
  duration: varchar("duration", { length: 255 }).notNull(),
  location: varchar("location", { length: 255 }).notNull(),
  highlights: jsonb("highlights").$type<string[]>().notNull(),
  skills: jsonb("skills").$type<string[]>().notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const projects = pgTable("projects", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description").notNull(),
  image: text("image"),
  link: text("link"),
  github: text("github"),
  tags: jsonb("tags").$type<string[]>().notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const profile = pgTable("profile", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  tagline: text("tagline"),
  about: text("about").notNull(),
  techSkills: jsonb("tech_skills").$type<string[]>().notNull(),
  avatarUrl: text("avatar_url"),
  yearsExperience: varchar("years_experience", { length: 50 }),
  studentsMentored: varchar("students_mentored", { length: 50 }),
  github: varchar("github", { length: 255 }),
  linkedin: varchar("linkedin", { length: 255 }),
  email: varchar("email", { length: 255 }),
  blogRssUrl: text("blog_rss_url"),
  googleScholarUrl: text("google_scholar_url"),
  location: varchar("location", { length: 255 }),
  role: varchar("role", { length: 255 }),
  community: varchar("community", { length: 255 }),
  experienceTitle: varchar("experience_title", { length: 255 }),
  experienceSub: varchar("experience_sub", { length: 255 }),
  mentorshipTitle: varchar("mentorship_title", { length: 255 }),
  mentorshipSub: varchar("mentorship_sub", { length: 255 }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const education = pgTable("education", {
  id: serial("id").primaryKey(),
  degree: varchar("degree", { length: 255 }).notNull(),
  field: varchar("field", { length: 255 }).notNull(),
  institution: varchar("institution", { length: 255 }).notNull(),
  institutionType: varchar("institution_type", { length: 255 }),
  date: varchar("date", { length: 255 }).notNull(),
  description: text("description"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const certifications = pgTable("certifications", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  issuer: varchar("issuer", { length: 255 }).notNull(),
  credentialId: varchar("credential_id", { length: 255 }),
  credentialUrl: text("credential_url"),
  date: varchar("date", { length: 255 }),
  logoUrl: text("logo_url"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const awards = pgTable("awards", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  issuer: varchar("issuer", { length: 255 }),
  year: varchar("year", { length: 50 }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const blogs = pgTable("blogs", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description").notNull(),
  link: text("link").notNull(),
  date: varchar("date", { length: 255 }).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const publications = pgTable("publications", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description").notNull(),
  link: text("link").notNull(),
  publisher: varchar("publisher", { length: 255 }),
  date: varchar("date", { length: 255 }).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const patents = pgTable("patents", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description").notNull(),
  link: text("link").notNull(),
  date: varchar("date", { length: 255 }).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});
