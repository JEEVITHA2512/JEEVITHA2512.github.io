import { neon } from '@neondatabase/serverless';
import * as dotenv from 'dotenv';

dotenv.config();

async function migrate() {
  if (!process.env.DATABASE_URL) {
    throw new Error("DATABASE_URL is not set");
  }

  const sql = neon(process.env.DATABASE_URL);

  console.log("Adding experience_title, experience_sub, mentorship_title, mentorship_sub columns to profile table...");

  await sql`ALTER TABLE profile ADD COLUMN IF NOT EXISTS experience_title VARCHAR(255)`;
  await sql`ALTER TABLE profile ADD COLUMN IF NOT EXISTS experience_sub VARCHAR(255)`;
  await sql`ALTER TABLE profile ADD COLUMN IF NOT EXISTS mentorship_title VARCHAR(255)`;
  await sql`ALTER TABLE profile ADD COLUMN IF NOT EXISTS mentorship_sub VARCHAR(255)`;

  console.log("Columns added successfully.");

  console.log("Backfilling default values...");
  await sql`
    UPDATE profile
    SET
      experience_title = COALESCE(experience_title, 'Experience'),
      experience_sub = COALESCE(experience_sub, 'Full-time & Internship work'),
      mentorship_title = COALESCE(mentorship_title, 'Mentorship'),
      mentorship_sub = COALESCE(mentorship_sub, 'AWS Clubs & User Groups guided')
    WHERE experience_title IS NULL OR experience_sub IS NULL OR mentorship_title IS NULL OR mentorship_sub IS NULL
  `;

  console.log("Migration complete!");
  process.exit(0);
}

migrate().catch((err) => {
  console.error("Migration failed:", err);
  process.exit(1);
});
