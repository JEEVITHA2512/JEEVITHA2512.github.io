import { neon } from '@neondatabase/serverless';
import * as dotenv from 'dotenv';

dotenv.config();

async function migrate() {
  if (!process.env.DATABASE_URL) {
    throw new Error("DATABASE_URL is not set");
  }

  const sql = neon(process.env.DATABASE_URL);

  console.log("Adding institution_type and description columns to education table...");
  await sql`ALTER TABLE education ADD COLUMN IF NOT EXISTS institution_type VARCHAR(255)`;
  await sql`ALTER TABLE education ADD COLUMN IF NOT EXISTS description TEXT`;

  console.log("Backfilling defaults for existing rows...");
  await sql`
    UPDATE education
    SET
      institution_type = COALESCE(institution_type, 'Higher Education / Academic'),
      description = COALESCE(description,
        'Pursued intensive academic coursework in ' || field || ' at ' || institution || '.'
      )
    WHERE institution_type IS NULL OR description IS NULL
  `;

  console.log("Migration complete!");
  process.exit(0);
}

migrate().catch((err) => {
  console.error("Migration failed:", err);
  process.exit(1);
});
