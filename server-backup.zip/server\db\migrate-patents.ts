import { db } from "./index";
import { publications, patents } from "./schema";
import { eq } from "drizzle-orm";

async function run() {
  console.log("Migrating patents...");
  
  // 1. Get all patents from publications
  const pubs = await db.select().from(publications).where(eq(publications.publisher, "Patent"));
  
  if (pubs.length > 0) {
    // 2. Insert into patents table
    await db.insert(patents).values(
      pubs.map(p => ({
        title: p.title,
        description: p.description,
        link: p.link,
        date: p.date
      }))
    );
    
    // 3. Delete from publications table
    await db.delete(publications).where(eq(publications.publisher, "Patent"));
    
    console.log(`Migrated ${pubs.length} patents successfully!`);
  } else {
    console.log("No patents found to migrate.");
  }
  
  process.exit(0);
}

run().catch(console.error);
