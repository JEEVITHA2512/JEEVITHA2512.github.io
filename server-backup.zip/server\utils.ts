/**
 * Utility to clean request payloads before passing them to Drizzle ORM.
 * This strips out auto-generated columns (like id, createdAt, updatedAt, created_at, updated_at)
 * to avoid driver-level type conversion errors (e.g. TypeError: value.toISOString is not a function).
 */
export const cleanPayload = (body: any, isUpdate = false) => {
  if (!body || typeof body !== "object") return {};
  
  const cleaned = { ...body };
  delete cleaned.id;
  delete cleaned.createdAt;
  delete cleaned.updatedAt;
  delete cleaned.created_at;
  delete cleaned.updated_at;
  
  if (isUpdate) {
    cleaned.updatedAt = new Date();
  }
  
  return cleaned;
};
